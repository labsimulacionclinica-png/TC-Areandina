// Flujo del examen de TC: paciente → sala → topograma → protocolo → contraste → adquisición → visor → informe.
import { buildAnatomy, serialize, LANDMARKS, lesion, structureAt, HARD_FACTOR, mulberry32 } from './phantom.js';
import { COLLIMATIONS, KERNELS, WINDOWS, SCANNER, DRL, K_EFFECTIVE, doseReport, masProfile, dwFromTopogram, expectedNoise, ctdiVol, organDoses, heartDisplacement } from './ct.js';
import { computeCurves, enhancementAt, CATHETERS, injectionSummary } from './contrast.js';
import { CASES, caseByKey, allCases, METAL_ITEMS, METAL_Z, loadCustomCases, saveCustomCases } from './cases.js';
import { PROTOCOLS, PARAM_DEFS } from './protocols.js';
import { ReconPool } from './pool.js';
import { Viewer, drawTopogram } from './viewer.js';
import { evaluate, loadHistory, saveToHistory, exportJson, exportCsv, reportHtml, escapeHtml } from './evaluation.js';
import { ARTIFACT_CASES, ARTIFACT_TYPES, artifactByKey, evaluateArtifact } from './artifacts.js';
import { dicomSlice, zip, uid } from './dicom.js';
import { Tour } from './tour.js';
import { lms } from './lms.js';
import { tourSteps } from './tourSteps.js';
import { perfusionMaps, perfusionSummary } from './perfusion.js';
import { dualEnergyImages, DE_OUTPUTS, parseOutput } from './dualenergy.js';

const $ = (id) => document.getElementById(id);
const pool = new ReconPool();
const fmt = (v, d = 0) => (Number.isFinite(v) ? v.toLocaleString('es', { minimumFractionDigits: d, maximumFractionDigits: d }) : '—');

const STEPS = [
  { key: 'paciente', label: 'Paciente' },
  { key: 'sala', label: 'Sala y posición' },
  { key: 'topograma', label: 'Topograma y rango' },
  { key: 'protocolo', label: 'Protocolo' },
  { key: 'contraste', label: 'Contraste' },
  { key: 'adquisicion', label: 'Adquisición' },
  { key: 'visor', label: 'Visor' },
  { key: 'finalizar', label: 'Finalizar' },
];

let S = null;        // estado del examen
let step = 'paciente';
let room = null;
let lastReport = null;
let scanning = false;
const viewer = new Viewer($('viewCanvas'), { onInfo: renderOverlay });

// ---------------------------------------------------------------------------
// Inicio
// ---------------------------------------------------------------------------

function practice() { return S?.mode === 'practica'; }

function newExam(caseKey, mode, student, classCode) {
  const c = caseByKey(caseKey);
  const rnd = mulberry32(Date.now() & 0xffff);
  S = {
    caseDef: c, mode, student, classCode, startTime: Date.now(),
    prep: { idAsked: false, idChecked: false, labsReviewed: false, pregnancyChecked: false, consent: false, contrastDecision: null, catheter: 'none', removed: new Set(), companion: 'dentro' },
    position: { orientation: 'head', arms: 'down', headHolder: false, strap: false, lasers: false, tableH: 0, baseOff: -(30 + Math.round(rnd() * 30)), zero: null, landmark: null, atIso: false, shields: new Set() },
    breathInstr: true,
    protocolKey: null, params: null, plan: [], injector: { volume: 80, flow: 3, conc: 350, saline: 30 },
    topos: [], topoIndex: 0, range: null,
    series: [], injected: false, adverse: false, extraSeries: 0,
    dose: { events: [], dlp: 0 },
    answer: null, dispatch: { sent: false, hydration: false, observation: false },
    visited: new Set(['paciente']),
    hr: c.patient.hr || null, betaBlocker: false,
  };
  $('log').innerHTML = '';
  $('scanLog').innerHTML = '';
  viewer.setSeries(null);
  log(`Caso: ${c.title}`, 'ok');
  $('modeBadge').hidden = false;
  $('modeBadge').textContent = mode === 'evaluacion' ? 'EVALUACIÓN' : 'PRÁCTICA';
  $('patientStrip').innerHTML = `<b>${escapeHtml(c.patient.name)}</b> · ${c.patient.age} años · ${c.patient.weight} kg · ${escapeHtml(c.title)}`;
  renderPatient();
  renderRoomControls();
  renderTopoControls();
  renderProtocolSelect();
  renderParams();
  renderInjector();
  renderSeriesTabs();
  renderFinal();
  updateDose();
  goto('paciente');
}

function offY() { return S.position.baseOff + S.position.tableH; }

// ---------------------------------------------------------------------------
// Navegación y guía
// ---------------------------------------------------------------------------

function stepDone(k) {
  if (!S) return false;
  switch (k) {
    case 'paciente': return S.prep.idChecked && !!S.prep.contrastDecision;
    case 'sala': return S.position.zero != null && S.position.atIso;
    case 'topograma': return S.topos.length > 0 && !!S.range;
    case 'protocolo': return !!S.params;
    case 'contraste': return S.plan.every((p) => p.phase === 'simple') || S.prep.contrastDecision !== 'apto' || S.visited.has('contraste');
    case 'adquisicion': return S.series.length > 0;
    case 'visor': return S.visited.has('visor') && S.series.length > 0;
    case 'finalizar': return !!lastReport && lastReport.caseKey === S.caseDef.key;
    default: return false;
  }
}

function renderNav() {
  $('stepsNav').innerHTML = STEPS.map((s, i) => `<button data-step="${s.key}" class="${s.key === step ? 'active' : ''} ${stepDone(s.key) ? 'done' : ''}"><span class="n">${i + 1}</span>${s.label}</button>`).join('');
  for (const b of $('stepsNav').querySelectorAll('button')) b.onclick = () => goto(b.dataset.step);
}

function goto(k) {
  if (!S) return;
  step = k;
  S.visited.add(k);
  for (const sec of document.querySelectorAll('.step')) sec.classList.toggle('active', sec.dataset.step === k);
  if (k === 'sala') initRoom();
  if (k === 'topograma') drawTopo();
  if (k === 'protocolo') renderMetrics();
  if (k === 'contraste') renderInjector();
  if (k === 'adquisicion') renderPreflight();
  if (k === 'visor') { renderSeriesTabs(); viewer.draw(); }
  if (k === 'finalizar') renderFinal();
  renderNav();
  renderGuide();
}

function renderGuide() {
  if (!S) return;
  const c = S.caseDef, e = c.expected, p = c.patient;
  $('guideMode').textContent = practice() ? 'práctica: con pistas' : 'evaluación: sin pistas';
  const tips = [];
  const L = [];
  const ok = (cond, text) => L.push(`<li class="${cond ? 'ok' : ''}">${text}</li>`);
  switch (step) {
    case 'paciente':
      ok(S.prep.idChecked, 'Verifique dos identificadores (nombre y fecha de nacimiento).');
      ok(S.prep.labsReviewed, 'Revise función renal, alergias, metformina y embarazo.');
      ok(!!S.prep.contrastDecision, 'Registre la decisión sobre el contraste.');
      ok(S.prep.removed.size > 0, 'Retire los objetos metálicos de la zona a explorar.');
      ok(S.prep.companion !== 'dentro', 'Decida dónde queda el acompañante.');
      if (practice()) {
        if (c.contrast === 'contraindicado' && S.prep.labsReviewed) tips.push(['warn', 'FG < 30 mL/min/1,73 m² y reacción alérgica previa moderada-grave: el técnico no inyecta, consulta al radiólogo.']);
        if (c.contrast === 'si') tips.push(['', `Para ${e.maxFlow >= 5 ? 'caudales de 4–5 mL/s' : 'este estudio'} hace falta un catéter de 20G o mayor en la fosa antecubital.`]);
        if (c.contrast === 'no') tips.push(['', 'La orden es de un estudio simple: no se canaliza vía para contraste.']);
        if (p.sex === 'F' && p.age < 50) tips.push(['', 'Mujer en edad fértil: confirme la prueba de embarazo antes de irradiar.']);
      }
      break;
    case 'sala':
      ok(S.position.orientation === 'head', 'Paciente en decúbito supino, cabeza primero.');
      ok(e.armsDown ? S.position.arms === 'down' : S.position.arms === 'up', 'Brazos fuera del campo.');
      ok(Math.abs(offY()) <= 15, 'Centre la altura de la mesa con el láser coronal en la línea medioaxilar.');
      ok(S.position.zero != null, 'Marque el cero en el punto de referencia anatómico.');
      ok(S.position.atIso, 'Lleve al paciente al isocentro.');
      if (practice()) {
        tips.push(['', c.positionTip || (c.region === 'head' ?'Cráneo: brazos a los lados, cabeza en el soporte, cero en la línea orbitomeatal (nasion).' : c.region === 'chest' ? 'Tórax: brazos sobre la cabeza, cero en la escotadura esternal.' : 'Abdomen: brazos sobre la cabeza, cero en el apéndice xifoides.')]);
        if (!p.cooperative) tips.push(['warn', 'Paciente agitado: use soporte y cinta de sujeción para evitar el movimiento.']);
        if (p.breathHold && p.breathHold < 15) tips.push(['warn', `El paciente solo tolera una apnea de ~${p.breathHold} s.`]);
      }
      break;
    case 'topograma':
      ok(S.topos.length > 0, 'Adquiera el topograma.');
      ok(!!S.range, 'Planifique el rango sobre el topograma.');
      if (practice()) tips.push(['', `Debe cubrir: ${coverageText(e.coverage)}. Evite explorar de más: cada centímetro suma dosis.`]);
      break;
    case 'protocolo':
      ok(!!S.params, 'Cargue un protocolo y ajústelo.');
      if (practice()) {
        tips.push(['', `Protocolo sugerido: ${PROTOCOLS[e.protocolKey].label}. Nivel de referencia de dosis: CTDIvol ≤ ${DRL[e.drl]} mGy.`]);
        tips.push(['', 'Menos kV realza más el yodo (útil en angio) pero aumenta el ruido; el pitch alto acorta la apnea; el ATCM ajusta los mAs a cada nivel del paciente.']);
      }
      break;
    case 'contraste':
      if (practice()) tips.push(['', 'El realce depende del caudal de yodo (mL/s × mgI/mL), de la duración de la inyección y del peso. El bolo de suero empuja el contraste que queda en la vía.']);
      break;
    case 'adquisicion':
      if (practice()) tips.push(['', 'Con seguimiento del bolo, coloque la ROI dentro del vaso de referencia. Si la pone fuera, el disparo llegará tarde o no llegará.']);
      break;
    case 'visor':
      L.push('<li>Rueda: cortes. Arrastrar: ventana/nivel. Herramienta ROI: media y DE en HU.</li>');
      if (practice()) tips.push(['', 'Mida el ruido (DE) en una ROI homogénea y el realce en los vasos. Revise las reconstrucciones coronal y sagital.']);
      break;
    case 'finalizar':
      ok(S.answer != null, 'Responda la pregunta sobre las imágenes.');
      ok(S.dispatch.sent, 'Envíe las imágenes al PACS.');
      break;
  }
  $('guide').innerHTML = `<ul>${L.join('')}</ul>${tips.map(([cls, t]) => `<div class="tip ${cls}">${t}</div>`).join('')}`;
}

const coverageText = ([a, b]) => `de z ≈ ${a} a ${b} mm del paciente (${((b - a) / 10).toFixed(0)} cm)`;

function log(text, cls = '') {
  const li = document.createElement('li');
  li.className = cls;
  const t = S ? Math.round((Date.now() - S.startTime) / 1000) : 0;
  li.innerHTML = `<time>${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}</time>${escapeHtml(text)}`;
  $('log').prepend(li);
}

function ask(title, html, buttons, danger = false) {
  return new Promise((resolve) => {
    const d = $('alertDlg');
    d.classList.toggle('danger', danger);
    $('alertTitle').textContent = title;
    $('alertBody').innerHTML = html;
    $('alertBtns').innerHTML = '';
    buttons.forEach(([label, value, primary]) => {
      const b = document.createElement('button');
      b.textContent = label;
      if (primary) b.className = 'primary';
      b.onclick = () => { d.close(); resolve(value); };
      $('alertBtns').append(b);
    });
    d.showModal();
  });
}

function bindSeg(id, get, set) {
  const el = $(id);
  const paint = () => { for (const b of el.querySelectorAll('button')) b.classList.toggle('active', b.dataset.v === String(get())); };
  for (const b of el.querySelectorAll('button')) b.onclick = () => { set(b.dataset.v); paint(); renderNav(); renderGuide(); };
  paint();
  return paint;
}

// ---------------------------------------------------------------------------
// 1. Paciente
// ---------------------------------------------------------------------------

function renderPatient() {
  const c = S.caseDef, p = c.patient;
  $('orderCard').innerHTML = `<b>${escapeHtml(c.title)}</b><br>${escapeHtml(c.order)}<br><span class="muted">${escapeHtml(c.history)}</span><br><span class="muted">Paciente: ${escapeHtml(p.name)} · ${escapeHtml(p.id)} · nac. ${p.dob}</span>`;
  $('idCard').hidden = true;
  $('chkId').checked = false; $('chkId').disabled = true;
  $('labsCard').hidden = true;
  $('pregRow').hidden = true;
  $('chkPreg').checked = false;
  $('chkConsent').checked = false;
  $('selCatheter').innerHTML = Object.entries(CATHETERS).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('');
  $('selCatheter').value = 'none';
  $('metalList').innerHTML = c.items.map((k) => `<li><label><input type="checkbox" data-item="${k}"> Retirar ${METAL_ITEMS[k].toLowerCase()}</label></li>`).join('');
  for (const cb of $('metalList').querySelectorAll('input')) cb.onchange = () => {
    if (cb.checked) S.prep.removed.add(cb.dataset.item); else S.prep.removed.delete(cb.dataset.item);
    log(`${cb.checked ? 'Retiró' : 'Dejó'}: ${METAL_ITEMS[cb.dataset.item]}`);
    renderGuide();
  };
  bindSeg('segContrast', () => S.prep.contrastDecision, (v) => { S.prep.contrastDecision = v; log(`Decisión sobre el contraste: ${{ apto: 'apto', no: 'no requiere', consultar: 'suspender y consultar' }[v]}`, v === 'consultar' ? 'warn' : ''); });
  bindSeg('segCompanion', () => S.prep.companion, (v) => { S.prep.companion = v; room?.update({ companion: v }); });
}

$('btnAskId').onclick = () => {
  if (!S) return;
  const c = S.caseDef, p = c.patient;
  S.prep.idAsked = true;
  $('idCard').hidden = false;
  $('idCard').innerHTML = `Paciente: «Me llamo ${escapeHtml(p.name)}, nací el ${new Date(p.dob + 'T12:00').toLocaleDateString('es', { dateStyle: 'long' })}».<br>Brazalete: <span class="band">${escapeHtml(c.wristband.name)} · ${c.wristband.dob}</span>`;
  $('chkId').disabled = false;
  log('Preguntó nombre y fecha de nacimiento');
};
$('chkId').onchange = (e) => { S.prep.idChecked = e.target.checked; if (e.target.checked) log('Identidad verificada', 'ok'); renderNav(); renderGuide(); };
$('btnLabs').onclick = () => {
  if (!S) return;
  const p = S.caseDef.patient;
  S.prep.labsReviewed = true;
  const egfrCls = p.egfr < 30 ? 'alert' : p.egfr < 45 ? 'warn' : '';
  const allergyCls = /contraste/i.test(p.allergies) ? 'alert' : '';
  $('labsCard').hidden = false;
  $('labsCard').innerHTML = `Creatinina: <b>${p.creatinine} mg/dL</b> · FG estimado: <b class="${egfrCls}">${p.egfr} mL/min/1,73 m²</b><br>
    Alergias: <span class="${allergyCls}">${escapeHtml(p.allergies)}</span><br>
    Metformina: ${p.metformin ? '<span class="warn">Sí</span>' : 'No'} · Peso: ${p.weight} kg · Talla: ${p.height} cm<br>
    ${p.pregnancy ? `Embarazo: ${escapeHtml(p.pregnancy)}<br>` : ''}
    Capacidad de apnea: ${p.breathHold ? `≈ ${p.breathHold} s` : 'no aplica'} · ${p.cooperative ? 'Colaborador' : '<span class="warn">Poco colaborador / agitado</span>'}
    ${p.hr ? `<br>Frecuencia cardíaca: <b id="hrNow" class="${S.hr > 65 ? 'warn' : ''}">${S.hr} lpm</b> <button id="btnBeta" ${S.betaBlocker ? 'disabled' : ''}>Administrar betabloqueador (metoprolol)</button>` : ''}`;
  $('pregRow').hidden = !(p.sex === 'F' && p.age < 50);
  if ($('btnBeta')) $('btnBeta').onclick = () => {
    S.betaBlocker = true;
    S.hr = 58;
    $('hrNow').textContent = '58 lpm'; $('hrNow').className = '';
    $('btnBeta').disabled = true;
    log('Metoprolol administrado: frecuencia cardíaca 58 lpm', 'ok');
    renderMetrics(); renderGuide();
  };
  log('Revisó historia clínica y laboratorios');
  renderGuide();
};
$('chkPreg').onchange = (e) => { S.prep.pregnancyChecked = e.target.checked; renderGuide(); };
$('chkConsent').onchange = (e) => { S.prep.consent = e.target.checked; };
$('selCatheter').onchange = (e) => { S.prep.catheter = e.target.value; log(`Acceso venoso: ${CATHETERS[e.target.value].label}`); renderInjector(); };

// ---------------------------------------------------------------------------
// 2. Sala
// ---------------------------------------------------------------------------

async function initRoom() {
  if (room) { room.resize(); syncRoom(); return; }
  try {
    const { Room } = await import('./room.js');
    room = new Room($('roomCanvas'));
    syncRoom();
  } catch (err) {
    $('roomCanvas').innerHTML = `<p class="empty">No se pudo iniciar la vista 3D (${escapeHtml(err.message)}). Use los controles de la derecha.</p>`;
  }
}

function syncRoom() {
  room?.update({
    arms: S.position.arms, orientation: S.position.orientation, headHolder: S.position.headHolder, strap: S.position.strap,
    companion: S.prep.companion, lasers: S.position.lasers, tableHeight: offY() / 1000,
    tableTravel: S.position.atIso ? 0.75 : 0,
  });
}

function renderRoomControls() {
  bindSeg('segOrient', () => S.position.orientation, (v) => { S.position.orientation = v; log(v === 'head' ? 'Cabeza primero' : 'Pies primero'); syncRoom(); });
  bindSeg('segArms', () => S.position.arms, (v) => { S.position.arms = v; log(v === 'up' ? 'Brazos sobre la cabeza' : 'Brazos a los lados'); syncRoom(); });
  $('chkHolder').checked = false; $('chkStrap').checked = false; $('chkLasers').checked = false; $('chkBreath').checked = true;
  for (const cb of $('shieldRow').querySelectorAll('input')) {
    cb.checked = S.position.shields.has(cb.dataset.shield);
    cb.onchange = () => {
      if (cb.checked) S.position.shields.add(cb.dataset.shield); else S.position.shields.delete(cb.dataset.shield);
      log(`Protector de bismuto (${cb.dataset.shield}): ${cb.checked ? 'colocado' : 'retirado'}`);
      renderMetrics();
    };
  }
  $('rngHeight').value = 0;
  $('selLandmark').innerHTML = '<option value="">Punto de referencia…</option>' + Object.entries(LANDMARKS).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('');
  $('zeroState').textContent = 'Sin cero marcado.';
  renderLaser();
}

function renderLaser() {
  const o = Math.round(offY());
  $('lblHeight').textContent = `${S.position.tableH > 0 ? '+' : ''}${S.position.tableH} mm`;
  const st = $('laserState');
  if (!S.position.lasers) { st.textContent = 'Láseres apagados'; st.className = 'laser-state off'; return; }
  if (Math.abs(o) <= 5) { st.textContent = 'Láser coronal en la línea medioaxilar'; st.className = 'laser-state ok'; }
  else { st.textContent = `Láser coronal ${Math.abs(o)} mm por ${o < 0 ? 'ENCIMA' : 'DEBAJO'} de la línea medioaxilar`; st.className = 'laser-state'; }
}

$('chkHolder').onchange = (e) => { S.position.headHolder = e.target.checked; syncRoom(); renderGuide(); };
$('chkStrap').onchange = (e) => { S.position.strap = e.target.checked; syncRoom(); renderGuide(); };
$('chkBreath').onchange = (e) => { S.breathInstr = e.target.checked; };
$('chkLasers').onchange = (e) => { S.position.lasers = e.target.checked; renderLaser(); syncRoom(); };
$('rngHeight').oninput = (e) => { S.position.tableH = +e.target.value; renderLaser(); syncRoom(); renderGuide(); };
$('btnZero').onclick = () => {
  if (!S) return;
  const k = $('selLandmark').value;
  if (!S.position.lasers) return ask('Láseres apagados', '<p>Encienda los láseres para marcar el cero sobre el punto de referencia.</p>', [['Entendido', 0, true]]);
  if (!k) return;
  S.position.zero = Math.round(LANDMARKS[k].z * (S.caseDef.patient.scale || 1)); S.position.landmark = k;
  $('zeroState').textContent = `Cero en: ${LANDMARKS[k].label}.`;
  log(`Cero marcado en ${LANDMARKS[k].label}`);
  renderNav(); renderGuide(); renderTopoControls();
};
$('btnIso').onclick = () => {
  if (!S) return;
  if (S.position.zero == null) return ask('Falta el cero', '<p>Marque primero el cero con el láser.</p>', [['Entendido', 0, true]]);
  S.position.atIso = true;
  log('Paciente en el isocentro', 'ok');
  syncRoom(); renderNav(); renderGuide();
};

// ---------------------------------------------------------------------------
// Anatomía del paciente (según brazos y objetos no retirados)
// ---------------------------------------------------------------------------

function metalExtras() {
  const M = lesion.M, out = [];
  const add = (name, c, r, mat = M.metal) => out.push(lesion.ell(name, c, r, mat));
  const keep = S.caseDef.items.filter((k) => !S.prep.removed.has(k));
  for (const k of keep) {
    if (k === 'aretes') for (const s of [-1, 1]) add('arete', [s * 77, -4, 160], [2.5, 2.5, 4]);
    if (k === 'gafas') for (const s of [-1, 1]) add('gafas', [s * 32, 99, 146], [15, 1.5, 2], { hu: 50, bone: 3000 });
    if (k === 'protesisDental') for (let a = 20; a <= 160; a += 20) add('protesis', [38 * Math.cos((a * Math.PI) / 180), 44 + 30 * Math.sin((a * Math.PI) / 180), 207], [2.5, 2.5, 3]);
    if (k === 'horquillas') for (const s of [-1, 1]) add('horquilla', [s * 22, -84, 40], [1.2, 5, 1.2]);
    if (k === 'collar') for (let a = 0; a < 360; a += 30) add('collar', [62 * Math.cos((a * Math.PI) / 180), -4 + 62 * Math.sin((a * Math.PI) / 180), 300], [2, 2, 2]);
    if (k === 'brasier') for (const s of [-1, 1]) for (let x = 30; x <= 110; x += 10) add('aro', [s * x, 100 - Math.abs(x - 70) * 0.4, 500], [2, 2, 2]);
    if (k === 'cinturon') add('hebilla', [0, 106, 800], [18, 3, 12]);
    if (k === 'monedas') add('monedas', [100, 40, 925], [12, 2, 12]);
    if (k === 'piercing') add('piercing', [0, 110, 750], [3, 3, 3]);
    if (k === 'reloj' && S.position.arms === 'down') add('reloj', [214, -6, 790], [16, 16, 6]);
  }
  return out;
}

// Protectores de bismuto: láminas finas muy atenuantes sobre la piel (dan rayas y ruido en la parte anterior)
function shieldExtras() {
  const bi = { hu: 0, bone: 3500 }, out = [];
  if (S.position.shields.has('ojos')) out.push(lesion.ell('bismuto-ojos', [0, 101, 148], [44, 1.2, 14], bi));
  if (S.position.shields.has('tiroides')) out.push(lesion.ell('bismuto-tiroides', [0, 64, 285], [36, 1.2, 26], bi));
  if (S.position.shields.has('mamas') && S.caseDef.patient.sex === 'F') out.push(lesion.tube('bismuto-mamas', 420, 530, [0, 119], [0, 121], [105, 1.2], [105, 1.2], bi));
  return out;
}

let anatomyCache = { key: null, id: 0, structs: null };
async function ensureAnatomy() {
  const key = JSON.stringify([S.caseDef.key, S.position.arms, [...S.prep.removed].sort(), [...S.position.shields].sort(), S.caseDef.patient.weight, S.betaBlocker || false]);
  if (anatomyCache.key === key) return anatomyCache;
  const c = S.caseDef;
  const structs = serialize(buildAnatomy({ weight: c.patient.weight, sex: c.patient.sex, scale: c.patient.scale || 1, pregnantWeeks: c.patient.pregnantWeeks || 0, arms: S.position.arms, extras: [...c.extras, ...metalExtras(), ...shieldExtras()] }));
  const id = anatomyCache.id + 1;
  await pool.setAnatomy(id, structs);
  anatomyCache = { key, id, structs };
  return anatomyCache;
}

// ---------------------------------------------------------------------------
// 3. Topograma y planificación
// ---------------------------------------------------------------------------

function renderTopoControls() {
  const pr = PROTOCOLS[S.protocolKey] || null;
  const def = pr?.topo || { view: S.caseDef.region === 'head' ? 'LAT' : 'AP', start: S.caseDef.region === 'head' ? -170 : -100, length: S.caseDef.region === 'head' ? 260 : 450 };
  $('topoView').value = def.view; $('topoStart').value = def.start; $('topoLen').value = def.length;
  renderRangeInputs();
}

$('btnTopo').onclick = async () => {
  if (!S) return;
  if (S.position.zero == null || !S.position.atIso) return ask('Paciente no preparado', '<p>Marque el cero con el láser y lleve al paciente al isocentro (paso «Sala y posición»).</p>', [['Entendido', 0, true]]);
  await acquireTopogram($('topoView').value, +$('topoStart').value, Math.max(100, Math.min(1000, +$('topoLen').value)));
};

async function acquireTopogram(view, start, len) {
  const z0 = Math.max(-150, S.position.zero + start);
  $('btnTopo').disabled = true; $('topoInfo').textContent = 'Adquiriendo…';
  try {
    const an = await ensureAnatomy();
    const topo = await pool.topogram({ anatomyId: an.id, kv: 120, z0, z1: z0 + len, view, offX: 0, offY: offY(), seed: S.topos.length + 3 });
    topo.label = `Topograma ${view} ${S.topos.length + 1}`;
    S.topos.push(topo);
    S.topoIndex = S.topos.length - 1;
    const dlp = 0.02 * len;
    addDose(`${topo.label}`, 0.15, dlp);
    log(`${topo.label}: ${len} mm`, S.topos.length > 2 ? 'warn' : '');
    if (!S.range) {
      const [a, b] = S.caseDef.expected.coverage;
      const mid = (z0 + z0 + len) / 2;
      S.range = practice() ? [Math.max(z0, mid - 120), Math.min(z0 + len, mid + 120)] : [z0 + len * 0.25, z0 + len * 0.75];
      void a; void b;
    }
    renderTopoTabs(); drawTopo(); renderRangeInputs(); renderMetrics(); renderNav(); renderGuide();
  } finally {
    $('btnTopo').disabled = false; $('topoInfo').textContent = '';
  }
}

function renderTopoTabs() {
  $('topoTabs').innerHTML = S.topos.map((t, i) => `<button data-i="${i}" class="${i === S.topoIndex ? 'active' : ''}">${t.label}</button>`).join('');
  for (const b of $('topoTabs').querySelectorAll('button')) b.onclick = () => { S.topoIndex = +b.dataset.i; renderTopoTabs(); drawTopo(); };
}

let topoLayout = null;
function drawTopo() {
  const cv = $('topoCanvas');
  const topo = S?.topos[S.topoIndex];
  $('topoEmpty').hidden = !!topo;
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  if (!W || !H) return;
  cv.width = W * dpr; cv.height = H * dpr;
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  if (!topo) return;
  const img = drawTopogram(cv, topo);
  const wMm = topo.cols * topo.px, hMm = topo.rows * topo.dz;
  const sc = Math.min(W / wMm, H / hMm) * 0.98;
  const dw = wMm * sc, dh = hMm * sc, x0 = (W - dw) / 2, y0 = (H - dh) / 2;
  ctx.drawImage(img, x0, y0, dw, dh);
  topoLayout = { x0, y0, dw, dh, sc, topo };
  const zy = (z) => y0 + (z - topo.z0) * sc;
  // DFOV (ancho) y rango
  if (S.range) {
    const [a, b] = S.range;
    const dfov = S.params?.dfov || 380;
    const cx = x0 + dw / 2, half = (dfov / 2) * sc;
    ctx.fillStyle = 'rgba(242,193,78,.12)';
    ctx.fillRect(cx - half, zy(a), 2 * half, zy(b) - zy(a));
    ctx.strokeStyle = '#f2c14e'; ctx.lineWidth = 2;
    // Con el gantry inclinado, en el topograma lateral los límites del rango se ven oblicuos (eje horizontal = y)
    const tn = topo.view === 'LAT' ? Math.tan(((S.params?.tilt || 0) * Math.PI) / 180) : 0;
    const yAt = (xpx) => ((xpx - x0) / dw - 0.5) * topo.cols * topo.px; // mm (anterior a la derecha)
    for (const z of [a, b]) { ctx.beginPath(); ctx.moveTo(x0, zy(z + yAt(x0) * tn)); ctx.lineTo(x0 + dw, zy(z + yAt(x0 + dw) * tn)); ctx.stroke(); }
    ctx.setLineDash([5, 4]); ctx.lineWidth = 1;
    ctx.strokeRect(cx - half, zy(a), 2 * half, zy(b) - zy(a)); ctx.setLineDash([]);
    ctx.fillStyle = '#f2c14e'; ctx.font = '12px Segoe UI, sans-serif';
    ctx.fillText(`${fmtTable(a)} mm`, x0 + 4, zy(a) - 4);
    ctx.fillText(`${fmtTable(b)} mm`, x0 + 4, zy(b) + 14);
  }
  // marca del cero
  if (S.position.zero != null) {
    ctx.strokeStyle = 'rgba(255,60,60,.7)'; ctx.setLineDash([2, 4]);
    ctx.beginPath(); ctx.moveTo(x0, zy(S.position.zero)); ctx.lineTo(x0 + dw, zy(S.position.zero)); ctx.stroke(); ctx.setLineDash([]);
  }
  ctx.fillStyle = '#cfe3ee'; ctx.font = '11px Segoe UI, sans-serif';
  ctx.fillText(topo.view === 'AP' ? 'D' : 'P', x0 + 4, y0 + dh / 2);
  ctx.fillText(topo.view === 'AP' ? 'Iz' : 'A', x0 + dw - 16, y0 + dh / 2);
}

const fmtTable = (z) => Math.round(z - (S.position.zero ?? 0));

(() => {
  const cv = $('topoCanvas');
  let drag = null;
  const zAt = (e) => { const r = cv.getBoundingClientRect(); return topoLayout.topo.z0 + (e.clientY - r.top - topoLayout.y0) / topoLayout.sc; };
  cv.addEventListener('pointerdown', (e) => {
    if (!topoLayout || !S.range) return;
    const z = zAt(e), tol = 8 / topoLayout.sc;
    const [a, b] = S.range;
    drag = Math.abs(z - a) < tol ? 'a' : Math.abs(z - b) < tol ? 'b' : z > a && z < b ? { move: z } : null;
    if (drag) cv.setPointerCapture(e.pointerId);
  });
  cv.addEventListener('pointermove', (e) => {
    if (!drag || !topoLayout) return;
    const t = topoLayout.topo, z = Math.max(t.z0, Math.min(t.z1, zAt(e)));
    if (drag === 'a') S.range = [Math.min(z, S.range[1] - 10), S.range[1]];
    else if (drag === 'b') S.range = [S.range[0], Math.max(z, S.range[0] + 10)];
    else {
      const d = z - drag.move, len = S.range[1] - S.range[0];
      let a = Math.max(t.z0, Math.min(t.z1 - len, S.range[0] + d));
      S.range = [a, a + len]; drag.move = z;
    }
    S.range = S.range.map((v) => Math.round(v));
    drawTopo(); renderRangeInputs(); renderMetrics();
  });
  const end = () => { if (drag) { drag = null; renderNav(); renderGuide(); } };
  cv.addEventListener('pointerup', end);
  cv.addEventListener('pointercancel', end);
  new ResizeObserver(() => { if (step === 'topograma') drawTopo(); }).observe(cv);
})();

function renderRangeInputs() {
  const has = !!S?.range;
  $('rangeStart').value = has ? fmtTable(S.range[0]) : '';
  $('rangeEnd').value = has ? fmtTable(S.range[1]) : '';
  $('rangeLen').textContent = has ? `${S.range[1] - S.range[0]} mm` : '—';
}
for (const id of ['rangeStart', 'rangeEnd']) {
  $(id).onchange = () => {
    if (!S?.range) return;
    const a = +$('rangeStart').value + S.position.zero, b = +$('rangeEnd').value + S.position.zero;
    if (b - a >= 10) S.range = [a, b];
    renderRangeInputs(); drawTopo(); renderMetrics();
  };
}

// ---------------------------------------------------------------------------
// 4. Protocolo
// ---------------------------------------------------------------------------

function renderProtocolSelect() {
  $('selProtocol').innerHTML = '<option value="">Elija un protocolo…</option>' + Object.entries(PROTOCOLS).map(([k, p]) => `<option value="${k}">${p.label}</option>`).join('');
  $('params').innerHTML = '';
  $('seriesPlan').innerHTML = '<p class="muted">Cargue un protocolo.</p>';
  $('metrics').innerHTML = '';
  $('doseWarn').innerHTML = '';
}

$('btnLoadProtocol').onclick = () => {
  const k = $('selProtocol').value;
  if (!S || !k) return;
  const p = PROTOCOLS[k];
  S.protocolKey = k;
  S.params = { ...p.params, sfov: p.sfov };
  S.region = p.region;
  S.plan = JSON.parse(JSON.stringify(p.series));
  if (p.injector) S.injector = { ...p.injector };
  log(`Protocolo cargado: ${p.label}`);
  renderParams(); renderMetrics(); renderInjector(); renderNav(); renderGuide();
  if (!S.topos.length) renderTopoControls();
};

function renderParams() {
  const box = $('params');
  if (!S?.params) { box.innerHTML = ''; return; }
  box.innerHTML = PARAM_DEFS.map((d) => {
    const v = S.params[d.key];
    let input;
    if (d.type === 'select') input = `<select data-k="${d.key}">${d.options.map((o) => `<option value="${o}" ${String(o) === String(v) ? 'selected' : ''}>${d.labels?.[o] || String(o).replace('.', ',')}</option>`).join('')}</select>`;
    else if (d.type === 'bool') input = `<select data-k="${d.key}"><option value="1" ${v ? 'selected' : ''}>Sí</option><option value="0" ${!v ? 'selected' : ''}>No</option></select>`;
    else if (d.type === 'coll') input = `<select data-k="${d.key}">${Object.entries(COLLIMATIONS).map(([k, c]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${c.label}</option>`).join('')}</select>`;
    else if (d.type === 'kernel') input = `<select data-k="${d.key}">${Object.entries(KERNELS).map(([k, c]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${c.label}</option>`).join('')}</select>`;
    else input = `<input type="number" data-k="${d.key}" min="${d.min}" max="${d.max}" step="${d.step}" value="${v}">`;
    return `<div class="param"><label>${d.label}</label>${input}</div>`;
  }).join('');
  for (const el of box.querySelectorAll('[data-k]')) el.onchange = () => {
    const d = PARAM_DEFS.find((x) => x.key === el.dataset.k);
    let v = el.value;
    if (d.type === 'bool') v = v === '1';
    else if (d.type === 'number' || (d.type === 'select' && typeof d.options[0] === 'number')) v = +v;
    if (d.type === 'number') v = Math.max(d.min, Math.min(d.max, v));
    S.params[d.key] = v;
    renderMetrics(); drawTopo();
  };
  renderSeriesPlan();
}

function dwAt() {
  const t = S.topos.find((x) => x.view === 'AP') || S.topos[0];
  return t ? dwFromTopogram(t) : null;
}

function regionKey() { return S.region || S.caseDef.region; }

function renderMetrics() {
  if (!S?.params) return;
  const p = { ...S.params, hr: S.hr || 70 };
  const [a, b] = S.range || [0, 300];
  const r = doseReport(p, a, b, dwAt(), regionKey());
  const noise = expectedNoise(p, r.dw);
  const drl = DRL[S.caseDef.expected.drl];
  const cls = (v, lim) => (v > lim * 1.5 ? 'err' : v > lim ? 'warn' : 'ok');
  $('metrics').className = 'metrics five';
  $('metrics').innerHTML = [
    ['CTDIvol', `${fmt(r.ctdi, 1)} mGy`, practice() ? cls(r.ctdi, drl) : ''],
    ['DLP', `${fmt(r.dlp)} mGy·cm`, ''],
    ['Dosis efectiva', `${fmt(r.effective, 1)} mSv`, ''],
    ['SSDE', `${fmt(r.ssde, 1)} mGy`, ''],
    ['Tiempo', `${fmt(r.time, 1)} s`, S.caseDef.patient.breathHold && r.time > S.caseDef.patient.breathHold && S.region !== 'head' ? 'warn' : ''],
    ['Corriente', `${fmt(r.mA)} mA`, r.limited ? 'err' : ''],
    ['mAs medio', fmt(r.avgMas), ''],
    ['Velocidad mesa', `${fmt(r.speed)} mm/s`, ''],
    ['Ruido esperado', `≈ ${fmt(noise, 1)} HU`, ''],
    ['Cortes', fmt(Math.round((b - a) / p.thickness) + 1), ''],
  ].map(([k, v, c]) => `<div class="metric ${c}"><div class="k">${k}</div><div class="v">${v}</div></div>`).join('');
  const warns = [];
  if (!S.range) warns.push(['warnline', 'Aún no hay rango planificado: los valores usan 300 mm.']);
  if (r.limited) warns.push(['errline', `El tubo no alcanza los mAs pedidos (máx. ${SCANNER.maxMa[p.kv]} mA): baje el pitch o la velocidad de rotación, o suba el kV.`]);
  if (p.thickness < COLLIMATIONS[p.coll].minThk) warns.push(['errline', `Con ${COLLIMATIONS[p.coll].label} el grosor mínimo es ${COLLIMATIONS[p.coll].minThk} mm.`]);
  if (S.caseDef.patient.breathHold && r.time > S.caseDef.patient.breathHold && regionKey() !== 'head') warns.push(['warnline', `La adquisición dura ${fmt(r.time, 1)} s y el paciente tolera ~${S.caseDef.patient.breathHold} s de apnea.`]);
  if (p.sfov === 'head' && regionKey() !== 'head') warns.push(['errline', 'El SFOV de cabeza (300 mm) es menor que el cuerpo: habrá truncamiento.']);
  if (practice() && r.ctdi > drl) warns.push(['warnline', `CTDIvol por encima del nivel de referencia orientativo (${drl} mGy).`]);
  if ((p.tilt || 0) !== 0 && p.sfov !== 'head') warns.push(['warnline', 'La inclinación del gantry se usa sobre todo en cráneo (para sacar los cristalinos del haz).']);
  const od = organDoses(p, a, b, r.ctdi, { sex: S.caseDef.patient.sex, shields: S.position.shields });
  const organs = Object.values(od).map((o) => `${o.label}: <b>${fmt(o.dose, 1)} mGy</b>${o.inField ? ' (en el haz' + (o.shielded ? ', con bismuto' : '') + ')' : ''}`).join(' · ');
  $('doseWarn').innerHTML = `<p class="small">Dosis estimada a órganos superficiales — ${organs}</p>` + warns.map(([c, t]) => `<p class="${c}">${t}</p>`).join('');
}

function renderSeriesPlan() {
  const box = $('seriesPlan');
  box.innerHTML = S.plan.map((s, i) => {
    const t = s.timing || { mode: 'fixed', delay: 70 };
    const timing = s.phase === 'simple' ? '<span class="muted">Sin contraste</span>' : `
      <select data-f="mode" data-i="${i}"><option value="fixed" ${t.mode === 'fixed' ? 'selected' : ''}>Retardo fijo</option><option value="bt" ${t.mode === 'bt' ? 'selected' : ''}>Seguimiento del bolo</option></select>
      ${t.mode === 'bt' ? `nivel <input type="number" data-f="monitorZ" data-i="${i}" value="${fmtTable(t.monitorZ ?? 450)}"> mm · umbral <input type="number" data-f="threshold" data-i="${i}" value="${t.threshold ?? 100}"> HU · +<input type="number" data-f="delay" data-i="${i}" value="${t.delay ?? 5}"> s`
        : `a los <input type="number" data-f="delay" data-i="${i}" value="${t.delay ?? 70}"> s del inicio de la inyección`}`;
    return `<div class="series-row">
      <input type="text" data-f="name" data-i="${i}" value="${escapeHtml(s.name)}">
      <select data-f="phase" data-i="${i}">${['simple', 'arterial', 'portal', 'tardia', 'perfusion'].map((ph) => `<option value="${ph}" ${ph === s.phase ? 'selected' : ''}>${{ simple: 'Simple', arterial: 'Arterial', portal: 'Portal', tardia: 'Tardía / excretora', perfusion: 'Perfusión' }[ph]}</option>`).join('')}</select>
      <div class="timing">${timing}</div>
      <button data-del="${i}" title="Quitar serie">✕</button>
    </div>`;
  }).join('') + '<div class="row"><button id="btnAddSeries">+ Añadir serie</button></div>';
  for (const el of box.querySelectorAll('[data-f]')) el.onchange = () => {
    const s = S.plan[+el.dataset.i], f = el.dataset.f;
    if (f === 'name') s.name = el.value;
    else if (f === 'phase') { s.phase = el.value; if (el.value !== 'simple' && !s.timing) s.timing = { mode: 'fixed', delay: el.value === 'arterial' ? 35 : el.value === 'portal' ? 70 : 300 }; }
    else {
      s.timing ||= { mode: 'fixed', delay: 70 };
      if (f === 'mode') { s.timing.mode = el.value; if (el.value === 'bt') Object.assign(s.timing, { comp: 'aorta', monitorZ: s.timing.monitorZ ?? (S.range ? Math.round((S.range[0] + S.range[1]) / 2) : 450), threshold: 100, delay: 6 }); }
      else if (f === 'monitorZ') s.timing.monitorZ = +el.value + S.position.zero;
      else s.timing[f] = +el.value;
    }
    renderSeriesPlan(); renderInjector();
  };
  for (const b of box.querySelectorAll('[data-del]')) b.onclick = () => { S.plan.splice(+b.dataset.del, 1); renderSeriesPlan(); };
  $('btnAddSeries').onclick = () => { S.plan.push({ name: `Serie ${S.plan.length + 1}`, phase: 'simple' }); renderSeriesPlan(); };
}

// ---------------------------------------------------------------------------
// 5. Contraste
// ---------------------------------------------------------------------------

function renderInjector() {
  if (!S) return;
  const inj = S.injector;
  const defs = [['volume', 'Volumen (mL)', 10, 150, 5], ['flow', 'Caudal (mL/s)', 0.5, 7, 0.5], ['conc', 'Concentración (mgI/mL)', [300, 350, 370]], ['saline', 'Suero (mL)', 0, 80, 5]];
  $('injParams').innerHTML = defs.map(([k, l, a, b, st]) => `<div class="param"><label>${l}</label>${Array.isArray(a) ? `<select data-j="${k}">${a.map((o) => `<option ${o === inj[k] ? 'selected' : ''}>${o}</option>`).join('')}</select>` : `<input type="number" data-j="${k}" min="${a}" max="${b}" step="${st}" value="${inj[k]}">`}</div>`).join('');
  for (const el of $('injParams').querySelectorAll('[data-j]')) el.onchange = () => { S.injector[el.dataset.j] = +el.value; renderInjector(); };
  const sum = injectionSummary(inj);
  const cat = CATHETERS[S.prep.catheter];
  $('injMetrics').innerHTML = [
    ['Duración', `${fmt(sum.duration, 1)} s`],
    ['Yodo total', `${fmt(sum.iodineG, 1)} g`],
    ['Aporte de yodo', `${fmt(sum.iodineDeliveryRate, 2)} gI/s`],
    ['gI/kg', fmt(sum.iodineG / S.caseDef.patient.weight, 2)],
  ].map(([k, v]) => `<div class="metric"><div class="k">${k}</div><div class="v">${v}</div></div>`).join('');
  const w = [];
  if (S.prep.catheter === 'none') w.push('<p class="warnline">Sin acceso venoso: canalice una vena en el paso «Paciente».</p>');
  else if (inj.flow > cat.maxFlow) w.push(`<p class="errline">El caudal supera el máximo recomendado para el catéter ${cat.label} (${cat.maxFlow} mL/s): riesgo de extravasación.</p>`);
  if (S.prep.contrastDecision !== 'apto') w.push('<p class="warnline">El paciente no está registrado como apto para contraste.</p>');
  $('injWarn').innerHTML = w.join('');
  drawCurves();
}

function drawCurves() {
  const cv = $('curveCanvas');
  if (!cv.clientWidth) return;
  const show = practice();
  $('curveNote').textContent = show ? 'previsión orientativa' : 'oculta en modo evaluación';
  const comps = [['pa', 'Art. pulmonar', '#e5605a'], ['aorta', 'Aorta', '#f2c14e'], ['portal', 'Porta', '#3fb8e6'], ['liver', 'Hígado', '#4cc38a']];
  if (S.caseDef.key === 'higado-trifasico') comps.push(['hcc', 'Nódulo', '#c58af0']);
  const curves = computeCurves(S.injector, S.caseDef.patient);
  const marks = S.plan.filter((s) => s.phase !== 'simple' && s.timing?.mode === 'fixed').map((s) => [s.timing.delay, s.name]);
  plot(cv, show ? comps.map(([k, label, color]) => ({ label, color, f: (t) => (enhancementAt(curves, t)[k] || 0) * HARD_FACTOR.iodine[S.params?.kv || 120] })) : [], 120, 450, marks);
  $('curveLegend').innerHTML = show ? comps.map(([, l, c]) => `<span><i style="background:${c}"></i>${l}</span>`).join('') : '';
}

function plot(cv, lines, tMax, yMax, marks = [], points = null, threshold = null) {
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  const L = 38, B = 22, T = 8, R = 8;
  const X = (t) => L + (t / tMax) * (W - L - R), Y = (v) => H - B - (v / yMax) * (H - B - T);
  ctx.strokeStyle = '#2a3a45'; ctx.fillStyle = '#8399a7'; ctx.font = '10px Segoe UI, sans-serif';
  for (let v = 0; v <= yMax; v += yMax > 300 ? 100 : 50) { ctx.beginPath(); ctx.moveTo(L, Y(v)); ctx.lineTo(W - R, Y(v)); ctx.stroke(); ctx.fillText(String(v), 4, Y(v) + 3); }
  for (let t = 0; t <= tMax; t += tMax > 60 ? 20 : 10) ctx.fillText(`${t} s`, X(t) - 8, H - 6);
  for (const [t, label] of marks) {
    ctx.strokeStyle = '#d8e3ea'; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(X(t), T); ctx.lineTo(X(t), H - B); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#d8e3ea'; ctx.fillText(label, X(t) + 3, T + 10);
  }
  if (threshold != null) { ctx.strokeStyle = '#e5605a'; ctx.setLineDash([6, 3]); ctx.beginPath(); ctx.moveTo(L, Y(threshold)); ctx.lineTo(W - R, Y(threshold)); ctx.stroke(); ctx.setLineDash([]); }
  for (const ln of lines) {
    ctx.strokeStyle = ln.color; ctx.lineWidth = 2; ctx.beginPath();
    for (let t = 0; t <= tMax; t += tMax / 200) { const v = ln.f(t); t === 0 ? ctx.moveTo(X(t), Y(v)) : ctx.lineTo(X(t), Y(Math.min(v, yMax))); }
    ctx.stroke(); ctx.lineWidth = 1;
  }
  if (points) {
    ctx.fillStyle = '#f2c14e';
    for (const [t, v] of points) { ctx.beginPath(); ctx.arc(X(t), Y(Math.min(yMax, Math.max(0, v))), 3, 0, 7); ctx.fill(); }
  }
}

// ---------------------------------------------------------------------------
// 6. Adquisición
// ---------------------------------------------------------------------------

function renderPreflight() {
  if (!S) return;
  const items = [
    [S.prep.idChecked, 'Identidad verificada'],
    [!!S.prep.contrastDecision, 'Decisión sobre el contraste registrada'],
    [S.position.atIso, 'Paciente en el isocentro'],
    [S.topos.length > 0, 'Topograma adquirido'],
    [!!S.range, 'Rango planificado'],
    [!!S.params, 'Protocolo cargado'],
    [S.plan.length > 0, `${S.plan.length} serie(s) programada(s)`],
    [S.breathInstr || regionKey() === 'head', 'Instrucciones respiratorias activadas'],
  ];
  $('preflight').innerHTML = items.map(([ok, t]) => `<li class="${ok ? 'ok' : 'warn'}">${ok ? '✓' : '•'} ${t}</li>`).join('');
  $('btnScan').disabled = scanning || !S.topos.length || !S.range || !S.params || !S.plan.length;
}

// Eventos del paciente durante el examen (definidos por el caso): el estudiante elige qué hacer
async function patientEvent(when) {
  const ev = S.caseDef.event;
  if (!ev || ev.when !== when || S.event?.type === ev.type) return;
  const choice = await ask(ev.title, `<p>${escapeHtml(ev.text)}</p><p class="small">¿Qué hace?</p>`, ev.options.map((o, i) => [o, i, false]), ev.danger);
  const ok = choice === ev.correct;
  S.event = { type: ev.type, choice, ok, handledOk: ok };
  scanLog(`${ev.title}: ${ev.options[choice]}`, ok ? 'ok' : 'warn');
  if (practice()) await ask(ok ? 'Bien hecho' : 'Revise la conducta', `<p>${escapeHtml(ev.explanation)}</p>`, [['Continuar', 0, true]]);
}

// Inicio de la media vuelta de un corte: con ECG se espera a que el corazón llegue a la fase elegida
function gatedStart(t, p, phasePct = 75) {
  if (!p.ecg || p.ecg === 'none') return t;
  const hr = p.hr || 70, beat = 60 / hr;
  const ph = ((t * hr) / 60) % 1, target = phasePct / 100;
  const center = t + (((target - ph) % 1) + 1) % 1 * beat;
  return center - p.rot / 4; // la media vuelta queda centrada en la fase
}

function scanLog(t, cls = '') {
  const li = document.createElement('li');
  li.className = cls; li.textContent = t;
  $('scanLog').prepend(li);
  log(t, cls);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SIM_SPEED = 12; // segundos simulados por segundo real durante las esperas

async function waitSim(from, to, label) {
  for (let t = from; t < to; t += 0.5) {
    $('clock').textContent = `${label} · t = ${fmt(t, 1)} s`;
    await sleep(500 / SIM_SPEED);
  }
}

function addDose(name, ctdi, dlp) {
  S.dose.events.push({ name, ctdi, dlp });
  S.dose.dlp += dlp;
  updateDose();
}
function updateDose() {
  const k = K_EFFECTIVE[regionKey() || 'abdomen'] || 0.015;
  $('dlpTotal').textContent = S ? `${fmt(S.dose.dlp)} mGy·cm` : '0';
  $('effTotal').textContent = S ? `${fmt(S.dose.dlp * k, 1)} mSv` : '0';
}

// Seguimiento del bolo: imagen de referencia sin contraste, ROI del usuario y monitorización
async function boluTracking(series, enhAt, an, tInj = 0) {
  const t = series.timing, p = S.params;
  $('btEmpty').hidden = true;
  $('btNote').textContent = `nivel ${fmtTable(t.monitorZ)} mm · umbral ${t.threshold} HU`;
  const job = { anatomyId: an.id, kv: p.kv, z: t.monitorZ, thickness: 10, enh: {}, mas: 20, kernel: 'standard', sfov: p.sfov, dfov: p.dfov, offX: 0, offY: offY(), rot: p.rot, seed: 99 };
  const base = await pool.slice(job);
  addDose('Seguimiento: referencia', ctdiVol({ ...p, coll: '16x0.625' }, 20), ctdiVol({ ...p, coll: '16x0.625' }, 20) * 1);
  const cv = $('btCanvas'), bv = new Viewer(cv);
  bv.setSeries({ slices: [base], zs: [t.monitorZ], dfov: p.dfov, interval: 10 });
  bv.setWindow(400, 40);
  $('btHint').textContent = 'Haga clic en el centro del vaso de referencia para colocar la ROI.';
  const roi = await new Promise((resolve) => {
    const h = (e) => {
      const q = bv.toImage(e);
      if (!q) return;
      cv.removeEventListener('click', h);
      resolve({ cx: q.x, cy: q.y, r: 4 });
    };
    cv.addEventListener('click', h);
  });
  bv.roi = roi; bv.draw();
  const rpx = p.dfov / 256;
  const xIso = (roi.cx - 127.5) * rpx, yIso = (127.5 - roi.cy) * rpx;
  const st = structureAt(an.structs, xIso, yIso - offY(), t.monitorZ);
  const baseHU = bv.roiStats(bv.current(), roi)?.mean ?? 0;
  const comp = st?.comp || null;
  scanLog(`ROI de seguimiento en: ${st ? st.name.replace(/-/g, ' ') : 'fuera del paciente'} (${fmt(baseHU)} HU)`, comp === series.timing.comp || (comp === 'pa' && series.timing.comp === 'pa') ? '' : 'warn');
  const rnd = mulberry32(5);
  const pts = [];
  const fI = HARD_FACTOR.iodine[p.kv];
  let trig = null;
  for (let tt = 6; tt <= 70; tt += 1.5) {
    const enh = comp ? (enhAt(tInj + tt)[comp] || 0) * fI : 0;
    const hu = baseHU + enh + (rnd() - 0.5) * 16;
    pts.push([tt, hu]);
    addDose('Seguimiento', 0, ctdiVol({ ...p, coll: '16x0.625' }, 20) * 0.5);
    plot($('btCurve'), [], 70, Math.max(400, t.threshold + 100), [], pts, t.threshold);
    $('clock').textContent = `Seguimiento del bolo · t = ${fmt(tt, 1)} s · ROI ${fmt(hu)} HU`;
    await sleep(1500 / SIM_SPEED * 2);
    if (hu >= t.threshold) { trig = tt; break; }
  }
  if (trig == null) { trig = 70; scanLog('El umbral no se alcanzó: disparo manual a los 70 s', 'err'); }
  else scanLog(`Disparo a los ${fmt(trig, 1)} s (${t.threshold} HU)`, 'ok');
  $('btHint').textContent = '';
  return tInj + trig;
}

async function runScan() {
  if (scanning) return;
  scanning = true;
  renderPreflight();
  const p0 = { ...S.params, hr: S.hr || 70 };
  S.hrAtScan = p0.hr;
  if (p0.ecg !== undefined) scanLog(`ECG: ${p0.hr} lpm · ${p0.ecg === 'none' ? 'sin sincronizar' : `${p0.ecg}, fase ${p0.phase} %`}`);
  scanLog(`Motor de reconstrucción: ${pool.engine}`);
  await patientEvent('start');
  const c = S.caseDef, pat = c.patient;
  const an = await ensureAnatomy();
  const dw = dwAt();
  // Inyecciones (puede haber una segunda, p. ej. perfusión tras la angio): realce = suma de todas
  const injs = [];
  const enhAt = (t) => {
    const out = {};
    for (const { curves, t0 } of injs) {
      if (t < t0) continue;
      const e = enhancementAt(curves, t - t0);
      for (const k in e) out[k] = (out[k] || 0) + e[k];
    }
    return out;
  };
  let prevEnd = -1e9; // instante (s desde la primera inyección) en que terminó la serie anterior
  const inject = (inj, t0, label) => {
    const cat = CATHETERS[S.prep.catheter];
    inj = { ...inj };
    if (inj.flow > cat.maxFlow + 1) {
      scanLog(`Extravasación: el inyector se detuvo por sobrepresión (${inj.flow} mL/s con ${cat.label})`, 'err');
      S.event = { type: 'extravasacion' };
      inj.volume = Math.min(inj.volume, inj.flow * 6);
    } else if (inj.flow > cat.maxFlow) scanLog(`Presión alta en el inyector: caudal por encima de lo recomendado para ${cat.label}`, 'warn');
    injs.push({ curves: computeCurves(inj, pat), t0 });
    S.injected = true;
    S.injectorUsed ||= inj;
    S.contrastTotal = (S.contrastTotal || 0) + inj.volume;
    scanLog(`${label}: ${inj.volume} mL a ${inj.flow} mL/s (${inj.conc} mgI/mL) + ${inj.saline} mL de suero`, 'ok');
  };
  try {
    for (let si = 0; si < S.plan.length; si++) {
      const plan = S.plan[si];
      const p = { ...p0, ...(plan.params || {}) };
      // La angio puede extenderse más allá del rango planificado (p. ej. desde el cayado aórtico)
      const z0 = S.range[0], z1 = plan.extendTo ? Math.max(S.range[1], plan.extendTo) : S.range[1];
      const fI = HARD_FACTOR.iodine[p.kv];
      let startT;
      const contrastPhase = plan.phase !== 'simple';
      if (contrastPhase && !injs.length && !S.noContrast) {
        // ¿se inyecta?
        if (S.prep.catheter === 'none') {
          const v = await ask('Sin acceso venoso', '<p>No hay catéter colocado. Sin vía no se puede inyectar.</p>', [['Adquirir sin contraste', 'skip'], ['Cancelar', 'cancel', true]]);
          if (v === 'cancel') return;
          S.noContrast = true;
        } else {
          let go = true;
          if (S.prep.contrastDecision !== 'apto') {
            const v = await ask('Contraste no autorizado', `<p>Usted registró: <b>${{ no: 'no requiere contraste', consultar: 'suspender y consultar al radiólogo' }[S.prep.contrastDecision] || 'sin decisión'}</b>. ¿Qué desea hacer?</p>`, [['Inyectar de todas formas', 'inj'], ['Adquirir sin contraste', 'skip', true], ['Cancelar', 'cancel']]);
            if (v === 'cancel') return;
            go = v === 'inj';
          }
          if (go) {
            inject(plan.injector || S.injector, 0, 'Inyección');
            if (c.contrast === 'contraindicado') {
              S.adverse = true;
              scanLog('REACCIÓN ADVERSA: urticaria, broncoespasmo e hipotensión al minuto de la inyección', 'err');
              await ask('Reacción adversa al contraste', '<p>A los 40 s de iniciar la inyección el paciente presenta urticaria generalizada, sibilancias e hipotensión. Se detiene el estudio y se activa el protocolo de reacciones (médico radiólogo, adrenalina, oxígeno).</p><p class="small">El paciente tenía una reacción previa moderada-grave y un FG de 24: el contraste estaba contraindicado.</p>', [['Entendido', 0, true]], true);
              break;
            }
            await patientEvent('injection');
          } else S.noContrast = true;
        }
      } else if (contrastPhase && injs.length && plan.reinject) {
        // Segunda inyección (bolo propio de la serie)
        const t0 = prevEnd + 20;
        await waitSim(Math.max(0, prevEnd), t0, 'Recargando el inyector');
        inject(plan.injector || S.injector, t0, 'Segunda inyección');
      }
      const haveContrast = injs.length > 0;
      const tInj = injs.length ? injs[injs.length - 1].t0 : 0;
      // Instante de inicio
      if (!contrastPhase || !haveContrast) startT = Math.max(prevEnd + 4, haveContrast ? prevEnd + 4 : -1e6);
      else if (plan.timing?.mode === 'bt') {
        const trig = await boluTracking(plan, enhAt, an, tInj);
        const minDelay = S.breathInstr && regionKey() !== 'head' ? 4 : 2;
        if (S.breathInstr && regionKey() !== 'head' && plan.timing.delay < 4) scanLog('El retardo tras el disparo es menor que la duración de la instrucción respiratoria: se usan 4 s', 'warn');
        startT = Math.max(trig + Math.max(plan.timing.delay, minDelay), prevEnd + 4);
      } else startT = Math.max(tInj + (plan.timing?.delay ?? 70), prevEnd + 4);
      if (haveContrast && startT > 0) await waitSim(Math.max(0, prevEnd), startT, 'Esperando el retardo');

      if (plan.phase === 'perfusion') {
        prevEnd = await perfusionSeries(plan, p, an, enhAt, startT, si);
        continue;
      }

      // Geometría y tiempos
      const zs = [];
      for (let z = z0; z <= z1 + 1e-6; z += p.thickness) zs.push(z);
      const rep = doseReport(p, z0, z1, dw, regionKey());
      const { mas } = masProfile(p, zs, dw);
      const times = zs.map((z) => gatedStart(startT + (z - z0) / rep.speed, p, p.phase));
      // Movimiento
      const chestAbd = regionKey() !== 'head';
      const tol = pat.breathHold || 0;
      let motionLabel = null;
      const rigid = (t) => {
        if (chestAbd && !S.breathInstr) { motionLabel = 'respiración'; return { amp: 7, period: 4, phase: 0 }; }
        if (chestAbd && tol && t - startT > tol) { motionLabel = 'apnea superada'; return { amp: 6, period: 3.5, phase: 0.7 }; }
        if (!chestAbd && !pat.cooperative && !S.position.strap) { motionLabel = 'cabeza'; return { head: 3.5 }; }
        if (S.event?.type === 'ansiedad' && !S.event.handledOk) { motionLabel = 'paciente ansioso'; return { head: 2.5, amp: 3, period: 3 }; }
        return null;
      };
      // En los protocolos cardíacos el corazón late durante la rotación
      const motionFor = (t) => {
        const m = rigid(t);
        if (p.ecg === undefined) return m;
        const [ax, ay] = heartDisplacement(t, p.hr, 5), [bx, by] = heartDisplacement(t + p.rot / 2, p.hr, 5);
        if (Math.hypot(bx - ax, by - ay) > 1.5 && !motionLabel) motionLabel = 'latido cardíaco';
        return { ...(m || {}), cardiac: { hr: p.hr, amp: 5 } };
      };
      const series = { name: plan.name, phase: plan.phase, params: p, zs, interval: p.thickness, dfov: p.dfov, slices: new Array(zs.length).fill(null), dose: rep, times, startT };
      series.position = { ...S.position };
      series.breathInstr = S.breathInstr;
      // Datos brutos: lo necesario para reconstruir de nuevo sin volver a irradiar
      series.acq = { z0, z1, startT, speed: rep.speed, anatomyId: an.id, enhAt, motionFor, p, offY: offY(), seedBase: si * 7919, masAt: (z) => masProfile(p, [z], dw).mas[0] };
      S.series.push(series);
      renderSeriesTabs(series);
      room?.update({ scanning: true });
      scanLog(`${plan.name}: ${zs.length} cortes, ${fmt(rep.time, 1)} s, CTDIvol ${fmt(rep.ctdi, 1)} mGy${rep.limited ? ' (límite del tubo)' : ''}`);
      let done = 0;
      const kvs = p.dualEnergy ? [80, 140] : [p.kv];
      const sets = kvs.map(() => new Array(zs.length).fill(null));
      const jobs = [];
      kvs.forEach((kv, e) => zs.forEach((z, k) => {
        const t = times[k];
        jobs.push(pool.slice({ anatomyId: an.id, kv, z, thickness: p.thickness, enh: enhAt(t), mas: mas[k] / kvs.length, kernel: p.kernel, sfov: p.sfov, dfov: p.dfov, offX: 0, offY: offY(), motion: motionFor(t), t, rot: p.rot, seed: si * 7919 + k * 31 + 1 + e * 5003, metalReduction: !!p.metalReduction, iterative: p.iterative || 0, tilt: p.tilt || 0 })
          .then((img) => {
            sets[e][k] = img;
            if (!p.dualEnergy) series.slices[k] = img;
            done++;
            $('scanBar').style.width = `${(100 * done) / jobs.length}%`;
            $('scanText').textContent = `${plan.name}: ${done}/${zs.length * kvs.length}`;
            if (haveContrast) $('clock').textContent = `Adquisición · t = ${fmt(startT + Math.min(rep.time, (done / jobs.length) * rep.time), 1)} s`;
            if (done % 8 === 0 && viewer.series === series) viewer.draw();
          }));
      }));
      await Promise.all(jobs);
      if (p.dualEnergy) {
        series.de = { low: sets[0], high: sets[1] };
        series.slices = dualEnergyImages(series.de, { type: 'vmi', kev: 70 });
        series.name += ' · VMI 70 keV';
        series.deOutput = { type: 'vmi', kev: 70 };
        renderSeriesTabs(series);
      }
      series.motion = motionLabel;
      if (motionLabel) scanLog(`Artefactos de movimiento (${motionLabel}) en ${plan.name}`, 'warn');
      // Realce medido en los niveles de interés (para la evaluación)
      const atZ = (z) => { const k = zs.reduce((best, zz, i) => (Math.abs(zz - z) < Math.abs(zs[best] - z) ? i : best), 0); return times[k]; };
      if (haveContrast) {
        const m = {};
        for (const [comp, z] of [['pa', 432], ['aorta', 620], ['portal', 635], ['liver', 620], ['hcc', 632], ['jugular', 250], ['cerebralArt', 125], ['venous', 60]]) m[comp] = (enhAt(atZ(z))[comp] || 0) * fI;
        series.measured = m;
      }
      series.ctdi = rep.ctdi;
      addDose(plan.name, rep.ctdi, rep.dlp);
      prevEnd = startT + rep.time;
      room?.update({ scanning: false });
      viewer.setSeries(series);
    }
    if (S.injected) await patientEvent('end');
    scanLog('Adquisición terminada', 'ok');
    goto('visor');
  } finally {
    scanning = false;
    room?.update({ scanning: false });
    $('clock').textContent = '';
    renderPreflight(); renderNav();
  }
}

// Perfusión: cine axial (sin mover la mesa) de 8 niveles de 5 mm (40 mm), una vuelta cada 1,5 s durante ~45 s.
async function perfusionSeries(plan, p, an, enhAt, startT, si) {
  const center = plan.centerZ ?? (S.range[0] + S.range[1]) / 2;
  const levels = [-17.5, -12.5, -7.5, -2.5, 2.5, 7.5, 12.5, 17.5].map((d) => center + d);
  const nF = 30, dt = 1.5;
  const times = Array.from({ length: nF }, (_, f) => startT + f * dt);
  const coll = COLLIMATIONS[p.coll];
  const ctdiFrame = ctdiVol({ ...p, coll: p.coll }, p.mas);
  const ctdi = ctdiFrame * nF, dlp = ctdi * 4;
  scanLog(`${plan.name}: ${levels.length} niveles × ${nF} tiempos (cada ${dt} s), ${p.kv} kV, CTDIvol ${fmt(ctdi)} mGy`);
  room?.update({ scanning: true });
  const frames = levels.map(() => new Array(nF).fill(null));
  let done = 0;
  const total = levels.length * nF;
  const jobs = [];
  levels.forEach((z, l) => times.forEach((t, f) => {
    jobs.push(pool.slice({ anatomyId: an.id, kv: p.kv, z, thickness: 5, enh: enhAt(t), mas: p.mas, kernel: 'brain', sfov: p.sfov, dfov: p.dfov, offX: 0, offY: offY(), motion: null, t, rot: p.rot, seed: si * 7919 + l * 977 + f * 31 + 3 })
      .then((img) => {
        frames[l][f] = img; done++;
        $('scanBar').style.width = `${(100 * done) / total}%`;
        $('scanText').textContent = `${plan.name}: ${done}/${total}`;
        $('clock').textContent = `Perfusión · t = ${fmt(t, 1)} s`;
      }));
  }));
  await Promise.all(jobs);
  // Serie dinámica (nivel central) para revisar las curvas
  const mid = 3;
  const dyn = { recon: true, derived: true, name: `${plan.name} · dinámica (nivel ${fmtTable(levels[mid])} mm)`, phase: 'perfusion', params: { ...p, thickness: 5, kernel: 'brain', window: 'brain' }, zs: times.map(() => levels[mid]), frameTimes: times, interval: 5, dfov: p.dfov, slices: frames[mid], dose: { ctdi, dlp, avgMas: p.mas }, times };
  S.series.push(dyn);
  // Mapas
  const maps = levels.map((_, l) => perfusionMaps(frames[l], times));
  const mk = (key, label, scale, unit, ww, wl) => ({
    name: `${label} (${unit})`, phase: 'perfusion-map', derived: true, recon: true, params: { ...p, thickness: 5, kernel: 'brain', window: null }, zs: levels, interval: 5, dfov: p.dfov,
    slices: maps.map((m) => Int16Array.from(m[key], (v) => Math.round(v * scale))), colormap: true, mapWindow: { ww, wl }, unitScale: scale, unit, dose: { ctdi: 0, dlp: 0, avgMas: p.mas },
  });
  const sCbf = mk('cbf', 'CBF', 1, 'mL/100 g/min', 80, 40), sCbv = mk('cbv', 'CBV', 10, 'mL/100 mL ×10', 60, 30), sTmax = mk('tmax', 'Tmax', 10, 's ×10', 160, 80), sMtt = mk('mtt', 'MTT', 10, 's ×10', 200, 100);
  S.series.push(sCbf, sCbv, sTmax, sMtt);
  const sum = perfusionSummary(maps, p.dfov / 256, 5);
  S.perfusion = sum;
  scanLog(`Perfusión: núcleo ≈ ${fmt(sum.coreMl)} mL (CBF < 30 %), hipoperfusión Tmax > 6 s ≈ ${fmt(sum.hypoMl)} mL, penumbra ≈ ${fmt(sum.mismatchMl)} mL, razón ${Number.isFinite(sum.ratio) ? fmt(sum.ratio, 1) : '∞'}`, 'ok');
  addDose(plan.name, ctdi, dlp);
  room?.update({ scanning: false });
  renderSeriesTabs(sCbf);
  return startT + nF * dt;
}


$('btnScan').onclick = async () => {
  if (S.series.some((s) => !s.recon)) {
    const v = await ask('Repetir la adquisición', '<p>Ya hay series adquiridas. Repetir añade dosis al paciente (y se tendrá en cuenta en la evaluación). Si solo necesita otro filtro, grosor o campo de visión, reconstruya desde los datos brutos en el visor.</p>', [['Repetir', 1], ['Cancelar', 0, true]]);
    if (!v) return;
    if (!S.artifact) S.extraSeries += S.plan.length;
  }
  runScan().catch((err) => { console.error(err); scanLog(`Error: ${err.message}`, 'err'); });
};

// ---------------------------------------------------------------------------
// 7. Visor
// ---------------------------------------------------------------------------

function renderSeriesTabs(sel) {
  const list = S?.series || [];
  if (sel) viewer.setSeries(sel);
  $('seriesTabs').innerHTML = list.map((s, i) => `<button data-i="${i}" class="${viewer.series === s ? 'active' : ''}">${s.recon ? `↻ ${escapeHtml(s.name)}` : `${escapeHtml(s.name)} · ${String(s.params.thickness).replace('.', ',')} mm`}</button>`).join('');
  for (const b of $('seriesTabs').querySelectorAll('button')) b.onclick = () => { const s = list[+b.dataset.i]; viewer.setSeries(s); windowFor(s); renderSeriesTabs(); };
  $('viewEmpty').hidden = list.length > 0;
  if (viewer.series && sel) windowFor(sel);
  syncReconPanel();
}

function syncReconPanel() {
  const s = viewer.series;
  $('reconPanel').hidden = !s;
  if (!s) return;
  $('rcKernel').innerHTML = Object.entries(KERNELS).map(([k, v]) => `<option value="${k}" ${k === s.params.kernel ? 'selected' : ''}>${v.label}</option>`).join('');
  $('rcThk').value = String(s.params.thickness);
  $('rcDfov').value = s.params.dfov;
  $('rcIr').value = String(s.params.iterative || 0);
  $('rcMar').checked = !!s.params.metalReduction;
  const src = s.deSource || s;
  $('deLbl').hidden = !src.de;
  if (src.de && !$('deOut').options.length) $('deOut').innerHTML = DE_OUTPUTS.map((o) => `<option value="${o.value}">${o.label}</option>`).join('');
  $('reconPanel').querySelector('.recon-row').style.opacity = s.derived ? 0.5 : 1;
  const gated = s.params.ecg === 'prospectivo' || s.params.ecg === 'retrospectivo';
  $('rcPhaseLbl').hidden = !gated;
  if (gated) $('rcPhase').value = String(s.params.phase);
}

function windowFor(s) {
  if (s.mapWindow) { viewer.setWindow(s.mapWindow.ww, s.mapWindow.wl); for (const b of $('segWindow').querySelectorAll('button')) b.classList.remove('active'); }
  else applyWindow(s.params.window || 'soft');
}

function applyWindow(k) {
  const w = WINDOWS[k];
  viewer.setWindow(w.ww, w.wl);
  for (const b of $('segWindow').querySelectorAll('button')) b.classList.toggle('active', b.dataset.v === k);
}

$('segWindow').innerHTML = Object.entries(WINDOWS).map(([k, w]) => `<button data-v="${k}">${w.label}</button>`).join('');
for (const b of $('segWindow').querySelectorAll('button')) b.onclick = () => applyWindow(b.dataset.v);
for (const b of $('segView').querySelectorAll('button')) b.onclick = () => { viewer.setView(b.dataset.v); for (const x of $('segView').querySelectorAll('button')) x.classList.toggle('active', x === b); };
$('segView').querySelector('button').classList.add('active');
for (const b of $('segTool').querySelectorAll('button')) b.onclick = () => { viewer.tool = b.dataset.v; for (const x of $('segTool').querySelectorAll('button')) x.classList.toggle('active', x === b); };
$('segTool').querySelector('button').classList.add('active');
viewer.onWindowChange = () => { for (const b of $('segWindow').querySelectorAll('button')) b.classList.remove('active'); };
$('rngSlice').oninput = (e) => {
  if (viewer.view === 'axial') viewer.index = +e.target.value; else viewer.mprRow = +e.target.value;
  viewer.roi = null; viewer.line = null; viewer.draw();
};
$('selSlab').onchange = (e) => { viewer.slab = +e.target.value; viewer.draw(); };

function renderOverlay(info) {
  const s = viewer.series;
  if (!info || !s) { for (const id of ['ovTL', 'ovTR', 'ovBL', 'ovBR']) $(id).textContent = ''; return; }
  const p = s.params;
  $('ovTL').textContent = `${S.caseDef.patient.name}\n${s.name}\n${p.kv} kV · ${Math.round(s.dose.avgMas)} mAs ef. · pitch ${p.pitch}`;
  $('ovTR').textContent = (info.view === 'axial' ? (s.frameTimes ? `Tiempo ${info.index + 1}/${info.n}\nt = ${fmt(s.frameTimes[info.index], 1)} s · mesa ${fmtTable(info.z)} mm` : `Corte ${info.index + 1}/${info.n}\nMesa ${fmtTable(info.z)} mm`) : `${info.view === 'coronal' ? 'Coronal' : 'Sagital'}\n${info.n} cortes`) + (viewer.slab ? `\nMIP ${viewer.slab} mm` : '');
  $('ovBL').textContent = `${p.thickness} mm · ${KERNELS[p.kernel].label}${p.iterative ? ` · IR ${p.iterative} %` : ''}${p.metalReduction ? ' · MAR' : ''}\nDFOV ${p.dfov} mm · CTDIvol ${fmt(s.dose.ctdi, 1)} mGy`;
  $('ovBR').textContent = `V ${Math.round(info.ww)} / N ${Math.round(info.wl)}${info.hover ? `\n${s.unit ? `= ${fmt(info.hover.hu / (s.unitScale || 1), 1)} ${s.unit.replace(/ ×10/, '')}` : `= ${info.hover.hu} HU`}` : ''}`;
  const r = $('rngSlice');
  r.max = info.view === 'axial' ? info.n - 1 : 255;
  r.value = info.view === 'axial' ? info.index : viewer.mprRow;
}

// Reconstrucción desde los datos brutos: mismo ruido de adquisición, sin dosis adicional
$('btnRecon').onclick = async () => {
  const base = viewer.series;
  if (!base?.acq) return;
  const src = base.recon ? base.source : base;
  const p = { ...src.params, kernel: $('rcKernel').value, thickness: +$('rcThk').value, dfov: Math.max(150, Math.min(500, +$('rcDfov').value)), iterative: +$('rcIr').value, metalReduction: $('rcMar').checked };
  const minT = COLLIMATIONS[p.coll].minThk;
  if (p.thickness < minT) { $('rcMsg').textContent = `Con ${COLLIMATIONS[p.coll].label} el grosor mínimo es ${minT} mm.`; return; }
  if (p.dfov > SCANNER.sfov[p.sfov]) { $('rcMsg').textContent = `El DFOV no puede superar el campo de medida (${SCANNER.sfov[p.sfov]} mm).`; return; }
  const a = src.acq, zs = [];
  // Fase cardíaca: la retrospectiva tiene datos de todo el ciclo; la prospectiva solo de un margen de ±5 %
  if (src.params.ecg === 'prospectivo' || src.params.ecg === 'retrospectivo') {
    p.phase = +$('rcPhase').value;
    if (src.params.ecg === 'prospectivo' && Math.abs(p.phase - src.params.phase) > 5) { $('rcMsg').textContent = `En prospectiva solo hay datos alrededor del ${src.params.phase} % (±5 %). Para elegir cualquier fase hace falta la retrospectiva.`; return; }
  }
  for (let z = a.z0; z <= a.z1 + 1e-6; z += p.thickness) zs.push(z);
  const times = zs.map((z) => gatedStart(a.startT + (z - a.z0) / a.speed, { ...a.p, phase: p.phase }, p.phase));
  const short = KERNELS[p.kernel].label.replace(/ \(.*\)/, '');
  const series = {
    name: `${src.name} · ${short} ${String(p.thickness).replace('.', ',')} mm${p.iterative ? ` · IR ${p.iterative} %` : ''}${p.metalReduction && !src.params.metalReduction ? ' · MAR' : ''}${p.phase !== src.params.phase ? ` · fase ${p.phase} %` : ''}`,
    phase: src.phase, params: p, zs, interval: p.thickness, dfov: p.dfov, slices: new Array(zs.length).fill(null),
    dose: src.dose, times, startT: a.startT, recon: true, source: src, acq: a, position: src.position, measured: src.measured,
  };
  S.series.push(series);
  renderSeriesTabs(series);
  applyWindow(p.kernel === 'lung' ? 'lung' : p.kernel === 'bone' ? 'bone' : src.params.window || 'soft');
  $('btnRecon').disabled = true;
  let done = 0;
  await Promise.all(zs.map((z, k) => {
    const t = times[k];
    return pool.slice({
      anatomyId: a.anatomyId, kv: p.kv, z, thickness: p.thickness, enh: a.enhAt ? a.enhAt(t) : {}, mas: a.masAt(z), kernel: p.kernel,
      sfov: p.sfov, dfov: p.dfov, offX: 0, offY: a.offY, motion: a.motionFor(t), t, rot: p.rot, seed: a.seedBase + Math.round(z * 7) + 1, metalReduction: p.metalReduction, iterative: p.iterative, tilt: p.tilt || 0,
    }).then((img) => {
      series.slices[k] = img;
      done++;
      $('rcMsg').textContent = `Reconstruyendo ${done}/${zs.length}…`;
      if (done % 8 === 0 && viewer.series === series) viewer.draw();
    });
  }));
  $('btnRecon').disabled = false;
  $('rcMsg').textContent = 'Listo: sin dosis adicional.';
  log(`Reconstrucción desde datos brutos: ${series.name}`, 'ok');
  viewer.draw();
};

// Doble energía: imágenes derivadas de los dos juegos (80 y 140 kV) sin nueva adquisición
$('btnDe').onclick = () => {
  const s = viewer.series, src = s?.deSource || s;
  if (!src?.de) return;
  const v = $('deOut').value, out = parseOutput(v), label = DE_OUTPUTS.find((o) => o.value === v).label;
  const ser = {
    ...src, name: `${src.name.replace(/ · VMI 70 keV$/, '')} · ${label}`, slices: dualEnergyImages(src.de, out), deSource: src, recon: true, derived: true, de: null,
    colormap: out.type === 'iodine', mapWindow: out.type === 'iodine' ? { ww: 100, wl: 50 } : null, unit: out.type === 'iodine' ? 'mg/mL ×10' : null, unitScale: out.type === 'iodine' ? 10 : 1,
  };
  S.series.push(ser);
  renderSeriesTabs(ser);
  log(`Doble energía: ${label}`, 'ok');
};

// Exportación DICOM de la serie visible
$('btnDicom').onclick = () => {
  const s = viewer.series;
  if (!s || s.slices.some((x) => !x)) return;
  const pat = S.caseDef.patient;
  S.studyUid ||= uid(); S.frameUid ||= uid();
  s.uid ||= uid();
  const ascii = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '');
  const meta = {
    patientName: ascii(pat.name).replace(/ /g, '^'), patientId: ascii(pat.id).replace(/\s/g, ''), birth: pat.dob, sex: pat.sex,
    studyUid: S.studyUid, seriesUid: s.uid, frameUid: S.frameUid, seriesNumber: S.series.indexOf(s) + 1, seriesDesc: ascii(s.name),
    date: new Date(S.startTime), kv: s.params.kv, mas: s.dose.avgMas, kernel: ascii(KERNELS[s.params.kernel].label), thickness: s.params.thickness, dfov: s.dfov, ww: viewer.ww, wl: viewer.wl,
  };
  const files = s.slices.map((img, i) => ({ name: `OpenTC/S${String(meta.seriesNumber).padStart(2, '0')}/IM${String(i + 1).padStart(4, '0')}.dcm`, data: dicomSlice(img, s.zs[i], i, meta) }));
  const url = URL.createObjectURL(zip(files));
  const a = document.createElement('a');
  a.href = url; a.download = `opentc-${S.caseDef.key}-serie${meta.seriesNumber}.zip`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  log(`Serie exportada en DICOM (${files.length} imágenes)`, 'ok');
};

// ---------------------------------------------------------------------------
// 8. Finalizar
// ---------------------------------------------------------------------------

function renderFinal() {
  if (!S) return;
  const art = S.artifact;
  const q = art
    ? { text: '¿Qué artefacto tiene la serie «Original»?', options: Object.values(ARTIFACT_TYPES), keys: Object.keys(ARTIFACT_TYPES) }
    : { ...S.caseDef.question, keys: S.caseDef.question.options.map((_, i) => i) };
  $('qText').textContent = q.text;
  $('qOptions').innerHTML = q.options.map((o, i) => `<label class="case"><input type="radio" name="qa" value="${i}" ${S.answer === q.keys[i] ? 'checked' : ''}><span>${escapeHtml(o)}</span></label>`).join('');
  for (const r of $('qOptions').querySelectorAll('input')) r.onchange = () => { S.answer = q.keys[+r.value]; renderGuide(); };
  $('chkSend').checked = S.dispatch.sent; $('chkHydration').checked = S.dispatch.hydration; $('chkObservation').checked = S.dispatch.observation;
  $('doseTable').innerHTML = `<thead><tr><th>Evento</th><th>CTDIvol</th><th>DLP</th></tr></thead><tbody>${S.dose.events.filter((e) => e.name !== 'Seguimiento').map((e) => `<tr><td>${escapeHtml(e.name)}</td><td>${fmt(e.ctdi, 2)} mGy</td><td>${fmt(e.dlp, 1)} mGy·cm</td></tr>`).join('')}
    ${S.dose.events.some((e) => e.name === 'Seguimiento') ? `<tr><td>Seguimiento del bolo (${S.dose.events.filter((e) => e.name === 'Seguimiento').length} exp.)</td><td></td><td>${fmt(S.dose.events.filter((e) => e.name === 'Seguimiento').reduce((a, e) => a + e.dlp, 0), 1)} mGy·cm</td></tr>` : ''}
    ${S.series.some((s) => s.recon) ? `<tr><td>Reconstrucciones desde datos brutos (${S.series.filter((s) => s.recon).length})</td><td>0</td><td>0 mGy·cm</td></tr>` : ''}</tbody>
    <tfoot><tr><td>Total</td><td></td><td>${fmt(S.dose.dlp, 1)} mGy·cm</td></tr></tfoot>`;
}
$('chkSend').onchange = (e) => { S.dispatch.sent = e.target.checked; if (e.target.checked) log('Imágenes enviadas al PACS', 'ok'); renderGuide(); };
$('chkHydration').onchange = (e) => { S.dispatch.hydration = e.target.checked; };
$('chkObservation').onchange = (e) => { S.dispatch.observation = e.target.checked; };

$('btnFinish').onclick = async () => {
  if (!S) return;
  if (S.answer == null) return ask('Falta la lectura', '<p>Responda la pregunta sobre las imágenes.</p>', [['Entendido', 0, true]]);
  let r;
  if (S.artifact) r = evaluateArtifact(S, S.answer);
  else {
    const acquired = S.series.filter((s) => !s.recon);
    const main = acquired.slice(-Math.max(1, S.plan.length));
    const rec = {
      caseDef: S.caseDef, student: S.student, startTime: S.startTime, prep: S.prep, position: { ...S.position, offY: offY() },
      range: acquired.length ? S.range : null, params: acquired[0]?.params, paramsList: S.series.map((s) => s.params), injected: S.injected, injector: S.injectorUsed || S.injector,
      catheterMax: CATHETERS[S.prep.catheter].maxFlow, series: main, maxCtdi: Math.max(0, ...acquired.map((s) => s.dose.ctdi)), totalDlp: S.dose.dlp,
      topograms: S.topos.length, extraSeries: S.extraSeries, answer: S.answer, dispatch: S.dispatch,
      hrAtScan: S.hrAtScan, event: S.event, perfusion: S.perfusion, topoMaxZ: Math.max(0, ...S.topos.map((x) => x.z1)),
      organs: acquired[0] ? organDoses(acquired[0].params, S.range[0], S.range[1], acquired[0].dose.ctdi, { sex: S.caseDef.patient.sex, shields: acquired[0].position?.shields || new Set() }) : null,
    };
    r = evaluate(rec);
  }
  lastReport = r;
  saveToHistory(r);
  if (lms.report(r)) log(`Nota enviada a la plataforma (SCORM ${lms.version === 2004 ? '2004' : '1.2'}): ${r.percent} %`, 'ok');
  $('reportBody').innerHTML = reportHtml(r);
  $('reportDlg').showModal();
  renderNav();
  if (S.classCode) {
    try {
      const res = await fetch(`api/classes/${encodeURIComponent(S.classCode)}/results`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(r) });
      log(res.ok ? `Informe enviado a la clase ${S.classCode}` : 'No se pudo enviar el informe a la clase', res.ok ? 'ok' : 'err');
    } catch { log('Sin conexión con el servidor de clase: descargue el JSON', 'err'); }
  }
};
$('btnJson').onclick = () => lastReport && exportJson(lastReport);
$('btnCsv').onclick = () => lastReport && exportCsv(lastReport);
$('btnPrint').onclick = () => { document.body.classList.add('printing-report'); window.print(); document.body.classList.remove('printing-report'); };

// ---------------------------------------------------------------------------
// Casos de artefactos
// ---------------------------------------------------------------------------

async function newArtifactExam(key, mode, student, classCode) {
  const a = artifactByKey(key);
  newExam(a.baseCase, mode, student, classCode);
  S.artifact = a;
  const c = a.weight ? { ...S.caseDef, patient: { ...S.caseDef.patient, weight: a.weight } } : S.caseDef;
  S.caseDef = c;
  $('patientStrip').innerHTML = `<b>${escapeHtml(c.patient.name)}</b> · ${c.patient.age} años · ${c.patient.weight} kg · ${escapeHtml(a.title)}`;
  // Paciente ya preparado y centrado
  Object.assign(S.prep, { idAsked: true, idChecked: true, labsReviewed: true, pregnancyChecked: true, consent: true, contrastDecision: 'no', companion: 'fuera', removed: new Set(c.items) });
  const pr = PROTOCOLS[a.protocol];
  Object.assign(S.position, { orientation: 'head', arms: c.expected.armsDown ? 'down' : 'up', headHolder: c.region === 'head', strap: c.region === 'head', lasers: true, tableH: -S.position.baseOff, zero: LANDMARKS[pr.landmark].z, landmark: pr.landmark, atIso: true });
  S.protocolKey = a.protocol;
  S.params = { ...pr.params, sfov: pr.sfov };
  S.region = pr.region;
  S.plan = [{ name: 'Original', phase: 'simple' }];
  a.setup(S);
  // Reflejar el estado en la interfaz
  renderPatient();
  $('chkId').disabled = false; $('chkId').checked = true;
  for (const cb of $('metalList').querySelectorAll('input')) cb.checked = true;
  renderRoomControls();
  Object.assign($('chkHolder'), { checked: S.position.headHolder });
  Object.assign($('chkStrap'), { checked: S.position.strap });
  Object.assign($('chkLasers'), { checked: true });
  Object.assign($('chkBreath'), { checked: S.breathInstr });
  $('rngHeight').value = S.position.tableH;
  $('selLandmark').value = pr.landmark;
  $('zeroState').textContent = `Cero en: ${LANDMARKS[pr.landmark].label}.`;
  renderLaser(); syncRoom();
  $('selProtocol').value = a.protocol;
  renderParams(); renderTopoControls();
  log(`Caso de artefacto: ${a.title}`, 'warn');
  goto('adquisicion');
  await acquireTopogram(pr.topo.view, pr.topo.start, pr.topo.length);
  S.range = [...c.expected.coverage];
  renderRangeInputs(); drawTopo();
  await runScan();
  S.originalSeries = S.series[0];
  S.plan[0].name = 'Repetición';
  renderNav();
  await ask('Serie con artefacto', `<p>${escapeHtml(a.brief)}</p><ol><li>Revise las imágenes (también en coronal y sagital).</li><li>Corrija la causa: sala, protocolo o reconstrucción desde los datos brutos.</li><li>Repita la adquisición solo si hace falta.</li><li>En «Finalizar», identifique el artefacto.</li></ol>`, [['Empezar', 0, true]]);
}

// ---------------------------------------------------------------------------
// Tutorial
// ---------------------------------------------------------------------------

let tour = null;
function startTour() {
  if ($('startDlg').open) $('startDlg').close();
  tour?.stop();
  lastReport = null;
  newExam('craneo-hic', 'practica', $('studentName').value.trim() || 'Tutorial', null);
  tour = new Tour(tourSteps({ S: () => S, step: () => step, offY, lastReport: () => (lastReport?.caseKey === 'craneo-hic' ? lastReport : null) }));
  tour.start();
}
$('btnTour').onclick = startTour;
$('btnStartTour').onclick = startTour;

// ---------------------------------------------------------------------------
// Diálogo inicial
// ---------------------------------------------------------------------------

let startMode = 'practica';
function openStart() {
  $('caseList').innerHTML = allCases().map((c, i) => `<label class="case"><input type="radio" name="case" value="${c.key}" ${i === 0 ? 'checked' : ''}><span><b>${escapeHtml(c.title)}</b>${c.custom ? ' <span class="badge">caso del docente</span>' : ''}<br><span class="muted">${escapeHtml(c.order)}</span></span></label>`).join('');
  $('artifactList').innerHTML = ARTIFACT_CASES.map((a) => `<label class="case"><input type="radio" name="case" value="${a.key}"><span><b>${escapeHtml(a.title)}</b><br><span class="muted">${escapeHtml(a.brief)}</span></span></label>`).join('');
  const hist = loadHistory();
  $('history').innerHTML = hist.length ? hist.slice(0, 8).map((r, i) => `<li><span>${new Date(r.date).toLocaleString('es', { dateStyle: 'short', timeStyle: 'short' })} · ${escapeHtml(r.student)} · ${escapeHtml(r.case)}</span><b>${r.percent} %</b><button data-h="${i}">Ver</button></li>`).join('') : '<li class="muted">Sin intentos todavía.</li>';
  for (const b of $('history').querySelectorAll('button')) b.onclick = () => { lastReport = hist[+b.dataset.h]; $('reportBody').innerHTML = reportHtml(lastReport); $('reportDlg').showModal(); };
  $('startDlg').showModal();
}
for (const b of $('segMode').querySelectorAll('button')) b.onclick = () => { startMode = b.dataset.v; for (const x of $('segMode').querySelectorAll('button')) x.classList.toggle('active', x === b); };
$('btnStart').onclick = async () => {
  const key = document.querySelector('input[name=case]:checked')?.value;
  const code = $('classCode').value.trim().toUpperCase();
  if (code) {
    try {
      const res = await fetch(`api/classes/${encodeURIComponent(code)}`);
      if (!res.ok) throw new Error();
      $('classMsg').textContent = '';
    } catch {
      $('classMsg').textContent = 'No se encontró esa clase en el servidor. Deje el campo vacío para practicar sin enviar resultados.';
      return;
    }
  }
  $('startDlg').close();
  const name = $('studentName').value.trim() || 'Sin nombre';
  if (artifactByKey(key)) newArtifactExam(key, startMode, name, code || null).catch((err) => { console.error(err); log(`Error: ${err.message}`, 'err'); });
  else newExam(key, startMode, name, code || null);
};
$('btnNew').onclick = openStart;
$('importCases').onchange = async (e) => {
  try {
    const data = JSON.parse(await e.target.files[0].text());
    const incoming = (Array.isArray(data) ? data : [data]).filter((d) => d?.key && d.patient && d.question && Array.isArray(d.lesions));
    const list = loadCustomCases();
    for (const d of incoming) { const i = list.findIndex((x) => x.key === d.key); if (i >= 0) list[i] = d; else list.push(d); }
    saveCustomCases(list);
    $('classMsg').textContent = `${incoming.length} caso(s) del docente importado(s).`;
    openStart();
  } catch { $('classMsg').textContent = 'El archivo no contiene casos válidos.'; }
  e.target.value = '';
};

// Enlaces directos: index.html?case=clave&mode=evaluacion&student=Nombre&class=ABC234 (útil desde Moodle)
const params = new URLSearchParams(location.search);
function startFromUrl() {
  const key = params.get('case');
  if (!key) return false;
  const mode = params.get('mode') === 'evaluacion' ? 'evaluacion' : 'practica';
  const student = params.get('student') || lms.studentName() || 'Sin nombre';
  if (artifactByKey(key)) { newArtifactExam(key, mode, student, params.get('class')); return true; }
  if (!caseByKey(key)) return false;
  newExam(key, mode, student, params.get('class'));
  return true;
}

window.addEventListener('resize', () => { if (step === 'contraste') drawCurves(); });
if ('serviceWorker' in navigator && !lms.active && location.protocol !== 'file:' && !location.hostname.match(/^(localhost|127\.)/)) navigator.serviceWorker.register('sw.js').catch(() => {});
renderNav();
if (!startFromUrl()) openStart();
