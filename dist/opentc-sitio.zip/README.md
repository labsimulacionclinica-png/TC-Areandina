# OpenTC Sim

Simulador educativo de tomografía computarizada (TC), libre y gratuito. Funciona en el navegador, sin instalación, sin registro y sin licencias. Es el complemento de [OpenRM Sim](../openrm-sim) para TC.

Las imágenes no se guardan precalculadas: se **simulan con física de TC**. El simulador proyecta un fantasma anatómico matemático, añade ruido cuántico y reconstruye cada corte por retroproyección filtrada. Por eso cada decisión del técnico (kV, mAs, pitch, filtro, centrado, brazos, apnea, sincronización del contraste) cambia la imagen.

## Flujo del examen

1. **Paciente**
   - Orden médica e identificación con dos identificadores (nombre y fecha de nacimiento) frente al brazalete.
   - Historia clínica: creatinina, FG, alergias, metformina y embarazo.
   - Decisión sobre el contraste, consentimiento y calibre del catéter (22G/20G/18G, con el caudal máximo de cada uno).
   - Retiro de objetos metálicos y ubicación del acompañante (dentro, con delantal plomado o fuera).
2. **Sala 3D** (Three.js, con realidad virtual WebXR)
   - Orientación del paciente, brazos, soporte de cabeza y cinta de sujeción.
   - Altura de la mesa con el láser coronal en la línea medioaxilar.
   - Cero marcado en un punto de referencia (nasion, escotadura esternal, xifoides…) y traslado al isocentro.
3. **Topograma** AP o lateral (con magnificación si la mesa está mal centrada). Planificación del rango arrastrando las líneas sobre el topograma.
4. **Protocolo**
   - Parámetros: kV, mAs efectivo, modulación de corriente (ATCM, calculada a partir del diámetro equivalente en agua del topograma), rotación, pitch, colimación, grosor, filtro, DFOV/SFOV y reducción de metal.
   - Indicadores en vivo: CTDIvol, DLP, dosis efectiva, SSDE, tiempo de adquisición, corriente del tubo (con su límite) y ruido esperado.
   - Series por fases: simple, arterial, portal y tardía, con retardo fijo o con seguimiento del bolo.
5. **Inyector**: volumen, caudal, concentración y bolo de suero. Muestra la curva de realce prevista para la aorta, la arteria pulmonar, la porta, el hígado y la lesión.
6. **Adquisición**
   - Seguimiento del bolo: el estudiante coloca la ROI en la imagen de referencia y el disparo se produce al superar el umbral.
   - Las series se reconstruyen en paralelo en Web Workers.
7. **Visor**: axial, coronal y sagital (MPR), presets de ventana, ventana/nivel con el ratón, ROI con media y DE en HU, y zoom.
8. **Finalizar**: lectura de las imágenes, envío al PACS, indicaciones tras el contraste e informe con rúbrica.

## Herramientas de aprendizaje

- **Tutorial guiado** (botón «Tutorial»): un TC de cráneo en 29 pasos. Resalta cada zona y espera a que el estudiante haga la acción real.
- **Reconstrucción desde los datos brutos** (en el visor): otro filtro, otro grosor, otro DFOV, reconstrucción iterativa (0–100 %) o MAR **sin volver a irradiar**. El ruido de la adquisición se conserva.
- **Reconstrucción iterativa**: difusión anisotrópica que conserva los bordes, mezclada con la FBP como en ASIR/ADMIRE. A porcentajes altos la textura se vuelve «plástica».
- **Casos de artefactos** (6): movimiento, metal, brazos en el campo, truncamiento, escalera en MPR y ruido en un paciente obeso. El paciente ya está escaneado; el estudiante identifica el artefacto, corrige la causa y repite o reconstruye. Se puntúa identificación (40), corrección (40), dosis (10) y tiempo (10).
- **Visor**: MIP de 10, 20 o 40 mm en axial, coronal y sagital, y medición de distancias.
- **Exportación DICOM** (ZIP): CT Image Storage con HU, geometría LPS y UID propios, para abrir las series en Horos, 3D Slicer o el PACS de prácticas. El nombre del paciente lleva el prefijo `SIMULADO`.

## Fase 2: rendimiento y realismo

- **Reconstrucción con WebGPU** (`js/gpu.js`, `js/gpuworker.js`): la proyección (muestreo bilineal por hardware en texturas `rg32float`), el filtrado (memoria compartida) y la retroproyección se hacen en la GPU. Dos workers de GPU con 4 cortes en vuelo cada uno, y los hilos de CPU ayudan cuando la GPU tiene cola. En una GPU AMD RDNA 3, 7,7 ms por corte frente a 55 ms en CPU, con la misma imagen (diferencia media 0,02 HU). Si no hay WebGPU se usa la CPU automáticamente.
- **Anatomía**: calota con tabla externa, díploe y tabla interna; surcos corticales y cisura interhemisférica; árbol bronquial con paredes; ventrículos derecho e izquierdo, aurículas y arterias coronarias (DA, Cx, CD).
- **Inclinación del gantry** (0 a −25°): el plano de corte se inclina de verdad (la rasterización usa z(y) = z + y·tan θ). En el topograma lateral el rango se dibuja oblicuo.
- **Dosis a órganos superficiales** (cristalino, tiroides, mamas), dentro o fuera del haz, y **protectores de bismuto**. Los protectores reducen la dosis del órgano un 35 %, pero producen rayas y ruido en la parte anterior; por eso hoy se prefiere la modulación por órgano. En cráneo, dejar los cristalinos en el haz resta puntos.
- **TC cardíaca con ECG**: el corazón se mueve según la fase del ciclo, y la diástasis se acorta al subir la frecuencia. Hay sincronización prospectiva (step and shoot) o retrospectiva (pitch 0,2, mucha más dosis), elección de fase y betabloqueador. Con la retrospectiva se puede reconstruir otra fase desde los datos brutos; con la prospectiva solo ±5 %. Nuevo caso: **angio-TC coronaria** con placa mixta y estenosis en la DA proximal, y nuevo criterio de rúbrica «Sincronización con el ECG».

## Fase 3: técnicas avanzadas y poblaciones especiales

- **Vasos cerebrales**: carótidas internas, polígono de Willis (ACM, ACA, ACP, comunicante anterior), basilar, vertebrales y senos venosos.
- **Perfusión cerebral** (`js/perfusion.js`):
  - El tejido realza según el modelo de dilución del indicador: CBV · (AIF ⊛ e^(−t/MTT)) con retraso.
  - La adquisición es un cine axial de 8 niveles de 5 mm × 30 tiempos (cada 1,5 s) a 80 kV.
  - Los mapas de CBF, CBV, MTT y Tmax se calculan por el método de los momentos y se ven en color.
  - La AIF se toma de los píxeles arteriales más precoces y se corrige el volumen parcial con la salida venosa (seno sagital).
  - Se informan los volúmenes de núcleo (CBF < 30 %, CBV bajo y Tmax > 6 s), de hipoperfusión (Tmax > 6 s) y la razón de mismatch.
  - Los valores absolutos de CBF salen algo altos; el patrón relativo (sano, penumbra, núcleo) es el que se usa para decidir.
- **Varias inyecciones** en un mismo examen (la perfusión lleva un segundo bolo) y **parámetros propios de cada serie** (kV, grosor, campo, rango extendido hasta el cayado aórtico).
- **Doble energía 80/140 kV** (`js/dualenergy.js`): descomposición agua/yodo por píxel. Genera imágenes monoenergéticas de 40 a 140 keV, mapa de yodo (mg/mL) e imagen sin contraste virtual. Reduce el ruido como los equipos reales: el yodo se estima suavizado y las imágenes se construyen sobre la mezcla de menor ruido. El calcio aparece en el mapa de yodo (limitación de dos materiales).
- **Eventos del paciente** con criterio en la rúbrica: calor por el contraste, urticaria leve, náuseas, paciente ansioso y niño que llora. En modo práctica se explica la conducta correcta.
- **Casos nuevos**:
  - **Código ictus**: TC simple, angio de troncos supraaórticos y Willis, y perfusión; oclusión de la ACM derecha con mismatch.
  - **Cráneo pediátrico**: anatomía escalada a un niño de 5 años, protocolo pediátrico, madre con delantal plomado y hematoma epidural con fractura.
  - **Embarazada de 24 semanas** con útero y feto: el topograma y el rango deben quedarse en el tórax.
  - **Paciente obeso** de 138 kg: el DFOV debe incluir toda la piel, y con la dosis estándar el realce queda bajo (contraste según el peso).

## Fase 4: docentes, Moodle, idiomas y tableta

- **Editor de casos** (`editor.html`): el docente crea casos sin programar. Define el paciente ficticio, la orden, el protocolo esperado, el contraste, los objetos metálicos, las lesiones (tipo, posición y tamaño, con aviso si caen fuera del paciente), la pregunta y la explicación. Tiene vista previa de la imagen.
  - Los casos se guardan en el navegador y se exportan o importan en JSON.
  - Los estudiantes los importan desde el diálogo inicial («Importar casos del docente»).
  - Se evalúan con la misma rúbrica: lo esperado (cobertura, filtros, dosis de referencia, fases) se deduce del protocolo.
- **Enlaces directos**: `index.html?case=angio-tep&mode=evaluacion&student=Ana&class=ABC234&lang=en` abre el caso sin pasar por el diálogo inicial.
- **Moodle (SCORM 1.2 / 2004)**: `js/lms.js` detecta la plataforma, toma el nombre del estudiante y envía la nota (0–100) y el estado aprobado/no aprobado (≥ 60 %).
  - Para generar el paquete:
    ```bash
    node scripts/build-scorm.mjs
    node scripts/build-scorm.mjs --case angio-tep --mode evaluacion
    ```
  - Se crea `dist/opentc-scorm*.zip`. En Moodle: *Añadir una actividad → Paquete SCORM → subir el ZIP*. La calificación pasa sola al libro de notas.
- **Idiomas**: español, inglés y portugués (selector en la barra superior o `?lang=en|pt`). Se traducen la interfaz, la guía, la rúbrica, el panel docente y el editor. Los textos clínicos de cada caso se muestran en el idioma en que se escribieron.
- **Tableta**:
  - En horizontal, los pasos van arriba y la guía al lado; en vertical, todo en una columna sin desplazamiento horizontal.
  - Los controles son más grandes con el dedo.
  - En el visor, la herramienta «Cortes» permite pasar cortes arrastrando y se hace zoom pellizcando con dos dedos.
  - La sala 3D admite gestos táctiles.

## Física simulada

- **Fantasma anatómico** de vértex a muslos (`js/phantom.js`). Incluye cerebro con sustancia gris y blanca, LCR y ventrículos; cráneo, peñascos y senos; cuello y tiroides; pulmones con trama vascular, corazón, aorta y arterias pulmonares; hígado, bazo, páncreas, riñones, vía urinaria, intestino y colon; columna con discos, costillas oblicuas, pelvis, fémures y brazos. El tejido adiposo cambia con el peso.
- **Reconstrucción** (`js/ct.js`):
  - Proyecciones paralelas (240 × 320) con perfil de corte y volumen parcial.
  - Filtro bowtie y ruido cuántico de Poisson más ruido electrónico.
  - Endurecimiento del haz por el calcio y el metal (rayas entre estructuras densas) y falta de fotones en el metal.
  - Movimiento rígido durante la rotación (respiración o cabeza), truncamiento fuera del SFOV y filtros de reconstrucción blando, estándar, cerebro, pulmón y hueso.
- **kV**: el yodo y el hueso realzan más a kV bajos; el tejido blando no cambia.
- **Contraste** (`js/contrast.js`):
  - Convolución del aporte de yodo con funciones de tránsito por compartimento, más una fase de recirculación.
  - Compartimentos: arteria pulmonar, aorta, porta, hígado, bazo, riñón (corticomedular y nefrográfico), fase excretora, vena cava superior con contraste casi puro y lavado de la lesión.
  - Efecto del bolo de suero, del peso, del gasto cardíaco y del FG.
- **Dosis**: nCTDIw por kV (maniquíes de 16 y 32 cm), sobrehaz de las colimaciones estrechas, sobrebarrido, coeficientes k de dosis efectiva y SSDE (AAPM 204/220).

## Casos (pacientes ficticios)

| Caso | Aprendizaje principal |
| --- | --- |
| Cráneo simple — hematoma | Convención radiológica (derecha a la izquierda de la imagen), fijación de un paciente agitado, brazos abajo |
| Angio-TC pulmonar — TEP | Seguimiento del bolo en el tronco pulmonar, flujo alto, suero, kV bajo, apnea corta |
| Hígado trifásico — hepatocarcinoma | Ventanas arterial tardía y portal; realce arterial con lavado |
| Urotomografía simple — litiasis | Protocolo de baja dosis, prueba de embarazo, cobertura de riñones a vejiga |
| Abdomen contrastado — contraindicación | FG 24, reacción previa grave y metformina: **no inyectar**, consultar (si se inyecta se simula una reacción adversa) |
| Tórax de baja dosis — nódulo | Cortes finos, filtro de pulmón, CTDIvol ≤ 3 mGy |
| Angio-TC de aorta — disección tipo B | Seguimiento del bolo en la aorta, cobertura de troncos supraaórticos a ilíacas, flap intimal y falsa luz con realce tardío |
| Cuello contrastado — absceso | Hombros bajos, fase venosa (~65 s), colección con pared que realza, prueba de embarazo |
| Tórax-abdomen-pelvis — trauma | Un solo rango de vértices a sínfisis, fase portal, laceración esplénica y hemoperitoneo, acompañante fuera |
| Pelvis — prótesis de cadera | Reducción de artefactos metálicos (MAR) y kV alto para ver una colección periprotésica |
| Angio-TC coronaria | Betabloqueador, sincronización con el ECG en diástole, cortes de 0,625 mm |
| Código ictus | Simple + angio de Willis + perfusión, segundo bolo, mismatch núcleo/penumbra |
| Cráneo pediátrico | Protocolo según tamaño, acompañante con delantal, hematoma epidural |
| Embarazada con sospecha de TEP | Justificación y limitar topograma y rango al tórax |
| Paciente obeso | DFOV que incluya la piel, kV/mAs y contraste según el peso |

**Modo práctica**: pistas en cada paso y curvas de realce visibles. **Modo evaluación**: sin pistas y con una rúbrica de 13 criterios. Los criterios son identificación, valoración del contraste, acceso venoso, metal, posicionamiento, centrado, cobertura, reconstrucción, dosis, sincronización, movimiento, hallazgo y despacho.

## Ejecutar en local

```bash
node server.mjs
```

Abra <http://localhost:5173>. No necesita `npm install`, porque Three.js r160 está incluido en `vendor/three/` (licencia MIT). Es una PWA y funciona sin conexión tras la primera visita.

## Panel del docente

Funciona igual que en OpenRM Sim. Con `node server.mjs 8080` en un equipo de la red, el docente crea una clase en `teacher.html` con un PIN y comparte el código de 6 letras. Los informes de los estudiantes llegan solos. Sin servidor (por ejemplo, en GitHub Pages), los estudiantes descargan el JSON y el docente lo arrastra al panel. Los datos se guardan en `data/` (o en la carpeta de `OPENTC_DATA`), que no se publica.

## Pruebas

```bash
npm test
```

Comprueban:

- HU y ruido del hígado y del cerebro, y la escala del ruido con los mAs y el filtro.
- Realce del yodo según el kV, rayas del metal y reducción de metal (MAR).
- Ruido con los brazos abajo, movimiento, topograma y magnificación.
- Dosis (CTDIvol, colimación, SSDE, ATCM) y curvas de realce (orden de llegada, lavado, fase excretora, suero).
- Posición de las lesiones, rúbrica y servidor de clase.

## Publicar gratis

Es un sitio estático. `.github/workflows/pages.yml` ejecuta las pruebas y publica en GitHub Pages en cada cambio de `main`.

## Estructura

| Archivo | Contenido |
| --- | --- |
| `js/phantom.js` | Fantasma anatómico, materiales y rasterización |
| `js/ct.js` | Proyección, ruido, reconstrucción FBP, topograma, dosis y ATCM |
| `js/contrast.js` | Curvas de realce e inyector |
| `js/cases.js` | Casos clínicos, objetos metálicos y preguntas |
| `js/protocols.js` | Protocolos de partida y parámetros |
| `js/main.js` | Flujo del examen e interfaz |
| `js/viewer.js` | Visor axial/MPR, ventana/nivel y ROI |
| `js/room.js` | Sala 3D y RV |
| `js/evaluation.js` | Rúbrica, informe, historial y exportación |
| `js/pool.js`, `js/worker.js` | Reconstrucción en paralelo |
| `teacher.html`, `js/teacher.js`, `js/classStats.js` | Panel del docente |
| `server.mjs` | Servidor estático y API de clases |

No usa datos de pacientes reales ni contenido de terceros. No es apto para uso clínico.
