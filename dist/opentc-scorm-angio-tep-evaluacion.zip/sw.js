// Service worker: permite usar la app sin conexión ("red primero": con conexión siempre sirve la versión más reciente).
const CACHE = 'opentc-v5';
const SHELL = [
  './', 'index.html', 'teacher.html', 'manifest.webmanifest', 'icon.svg',
  'css/styles.css', 'css/ct.css', 'css/teacher.css',
  'js/main.js', 'js/phantom.js', 'js/ct.js', 'js/contrast.js', 'js/cases.js', 'js/protocols.js', 'js/pool.js', 'js/worker.js',
  'js/viewer.js', 'js/room.js', 'js/artifacts.js', 'js/dicom.js', 'js/tour.js', 'js/tourSteps.js', 'js/gpu.js', 'js/gpuworker.js', 'js/perfusion.js', 'js/dualenergy.js', 'js/evaluation.js', 'js/classStats.js', 'js/teacher.js',
  'vendor/three/three.module.js', 'vendor/three/addons/controls/OrbitControls.js', 'vendor/three/addons/webxr/VRButton.js',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  // La API de clases nunca se guarda en caché (contiene resultados de estudiantes).
  if (req.method !== 'GET' || url.origin !== self.location.origin || url.pathname.includes('/api/')) return;
  e.respondWith(
    fetch(req)
      .then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      })
      .catch(() => caches.match(req, { ignoreSearch: true }).then((hit) => hit || caches.match('index.html'))),
  );
});
