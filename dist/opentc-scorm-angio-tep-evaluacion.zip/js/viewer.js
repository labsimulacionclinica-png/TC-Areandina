// Visor 2D: axial, coronal y sagital (MPR) con ventana/nivel, desplazamiento, ROI y lectura de HU.
import { rainbow } from './perfusion.js';
const N = 256;

export class Viewer {
  constructor(canvas, { onInfo } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.onInfo = onInfo || (() => {});
    this.series = null;
    this.view = 'axial';
    this.index = 0;     // corte axial
    this.mprRow = N / 2; // fila (coronal) o columna (sagital)
    this.ww = 400; this.wl = 40;
    this.zoom = 1;
    this.roi = null; this.line = null;
    this.tool = 'wl';
    this.off = document.createElement('canvas');
    this.bindEvents();
    new ResizeObserver(() => this.draw()).observe(canvas);
  }

  setSeries(series) {
    this.series = series;
    this.index = Math.min(this.index, Math.max(0, (series?.slices.length || 1) - 1));
    if (series && !this._kept) this.index = Math.floor(series.slices.length / 2);
    this.roi = null; this.line = null;
    this.draw();
  }
  setWindow(ww, wl) { this.ww = ww; this.wl = wl; this.draw(); }
  setView(v) { this.view = v; this.roi = null; this.line = null; this.draw(); }

  // Imagen 2D actual (Float32 o Int16) con sus dimensiones y aspecto del píxel
  current() {
    const s = this.series;
    if (!s || !s.slices.length) return null;
    const n = s.slices.length;
    const rpx = s.dfov / N, zsp = s.interval;
    const slab = this.slab || 0; // grosor del MIP en mm (0 = sin MIP)
    if (this.view === 'axial') {
      const c = Math.max(0, Math.min(n - 1, this.index));
      const img = s.slices[c];
      if (!img) return null;
      const h = Math.floor(slab / 2 / zsp);
      if (!h) return { img, w: N, h: N, aspect: 1 };
      const out = Int16Array.from(img);
      for (let k = Math.max(0, c - h); k <= Math.min(n - 1, c + h); k++) {
        const sl = s.slices[k];
        if (sl) for (let p = 0; p < N * N; p++) if (sl[p] > out[p]) out[p] = sl[p];
      }
      return { img: out, w: N, h: N, aspect: 1 };
    }
    const out = new Int16Array(N * n).fill(-1024);
    const r = Math.round(this.mprRow), h = Math.floor(slab / 2 / rpx);
    for (let k = 0; k < n; k++) {
      const sl = s.slices[k];
      if (!sl) continue;
      for (let rr = Math.max(0, r - h); rr <= Math.min(N - 1, r + h); rr++) {
        for (let j = 0; j < N; j++) {
          const v = this.view === 'coronal' ? sl[rr * N + j] : sl[j * N + rr];
          if (v > out[k * N + j]) out[k * N + j] = v;
        }
      }
    }
    // sagital: horizontal = anterior → posterior (fila de la imagen axial)
    return { img: out, w: N, h: n, aspect: zsp / rpx };
  }

  layout(cur) {
    const W = this.canvas.clientWidth, H = this.canvas.clientHeight;
    const iw = cur.w, ih = cur.h * cur.aspect;
    const scale = Math.min(W / iw, H / ih) * this.zoom;
    return { W, H, scale, dw: iw * scale, dh: ih * scale, x0: (W - iw * scale) / 2, y0: (H - ih * scale) / 2 };
  }

  draw() {
    const c = this.canvas, dpr = window.devicePixelRatio || 1;
    const W = c.clientWidth, H = c.clientHeight;
    if (!W || !H) return;
    if (c.width !== Math.round(W * dpr)) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
    const ctx = this.ctx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    const cur = this.current();
    if (!cur) { this.onInfo(null); return; }
    this.off.width = cur.w; this.off.height = cur.h;
    const octx = this.off.getContext('2d');
    const id = octx.createImageData(cur.w, cur.h);
    const lo = this.wl - this.ww / 2, k = 255 / this.ww;
    const color = this.series.colormap ? this.colorLut || (this.colorLut = Array.from({ length: 256 }, (_, i) => rainbow(i / 255))) : null;
    for (let p = 0; p < cur.w * cur.h; p++) {
      const g = Math.max(0, Math.min(255, (cur.img[p] - lo) * k));
      if (color) {
        const [r, gg, b] = cur.img[p] <= 0 ? [0, 0, 0] : color[g | 0];
        id.data[4 * p] = r; id.data[4 * p + 1] = gg; id.data[4 * p + 2] = b;
      } else id.data[4 * p] = id.data[4 * p + 1] = id.data[4 * p + 2] = g;
      id.data[4 * p + 3] = 255;
    }
    octx.putImageData(id, 0, 0);
    const L = this.layout(cur);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(this.off, L.x0, L.y0, L.dw, L.dh);
    // líneas de referencia en MPR
    if (this.view === 'axial' && this.showRef) {
      ctx.strokeStyle = 'rgba(242,193,78,.6)'; ctx.setLineDash([4, 4]);
      const y = L.y0 + (this.mprRow / N) * L.dh;
      ctx.beginPath(); ctx.moveTo(L.x0, y); ctx.lineTo(L.x0 + L.dw, y); ctx.stroke(); ctx.setLineDash([]);
    }
    if (this.line) {
      const l = this.line, X = (x) => L.x0 + x * L.scale, Y = (y) => L.y0 + y * cur.aspect * L.scale;
      ctx.strokeStyle = '#4cc38a'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(X(l.x0), Y(l.y0)); ctx.lineTo(X(l.x1), Y(l.y1)); ctx.stroke();
      const rpx = this.series.dfov / N;
      const mm = Math.hypot((l.x1 - l.x0) * rpx, (l.y1 - l.y0) * cur.aspect * rpx);
      ctx.fillStyle = '#4cc38a'; ctx.font = '12px Segoe UI, sans-serif';
      ctx.fillText(`${mm.toFixed(1)} mm`, X(l.x1) + 6, Y(l.y1));
    }
    if (this.roi) {
      const r = this.roi;
      ctx.strokeStyle = '#f2c14e'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(L.x0 + r.cx * L.scale, L.y0 + r.cy * cur.aspect * L.scale, Math.max(2, r.r * L.scale), 0, 2 * Math.PI); ctx.stroke();
      const st = this.roiStats(cur, r);
      if (st) {
        ctx.fillStyle = '#f2c14e'; ctx.font = '12px Segoe UI, sans-serif';
        ctx.fillText(`Media ${st.mean.toFixed(0)} HU · DE ${st.sd.toFixed(1)} · ${st.area.toFixed(0)} mm²`, L.x0 + (r.cx + r.r) * L.scale + 6, L.y0 + r.cy * cur.aspect * L.scale);
      }
    }
    this.onInfo(this.info());
  }

  roiStats(cur, r) {
    let s = 0, s2 = 0, n = 0;
    for (let y = Math.floor(r.cy - r.r); y <= Math.ceil(r.cy + r.r); y++) for (let x = Math.floor(r.cx - r.r); x <= Math.ceil(r.cx + r.r); x++) {
      if (x < 0 || y < 0 || x >= cur.w || y >= cur.h) continue;
      if ((x - r.cx) ** 2 + ((y - r.cy) * cur.aspect) ** 2 > r.r * r.r) continue;
      const v = cur.img[y * cur.w + x]; s += v; s2 += v * v; n++;
    }
    if (!n) return null;
    const mean = s / n, rpx = this.series.dfov / N;
    return { mean, sd: Math.sqrt(Math.max(0, s2 / n - mean * mean)), area: n * rpx * rpx * (this.view === 'axial' ? 1 : this.series.interval / rpx), n };
  }

  info() {
    const s = this.series;
    if (!s) return null;
    const z = this.view === 'axial' ? s.zs[this.index] : null;
    return { view: this.view, index: this.index, n: s.slices.length, z, ww: this.ww, wl: this.wl, hover: this.hover };
  }

  toImage(ev) {
    const cur = this.current();
    if (!cur) return null;
    const rect = this.canvas.getBoundingClientRect();
    const L = this.layout(cur);
    const x = (ev.clientX - rect.left - L.x0) / L.scale, y = (ev.clientY - rect.top - L.y0) / L.scale / cur.aspect;
    return { x, y, cur };
  }

  bindEvents() {
    const c = this.canvas;
    let drag = null;
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    c.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (!this.series) return;
      const d = Math.sign(e.deltaY);
      if (e.ctrlKey) { this.zoom = Math.max(0.5, Math.min(4, this.zoom * (d > 0 ? 0.9 : 1.1))); this.draw(); return; }
      if (this.view === 'axial') this.index = Math.max(0, Math.min(this.series.slices.length - 1, this.index + d));
      else this.mprRow = Math.max(0, Math.min(N - 1, this.mprRow + d * 2));
      this.roi = null; this.line = null;
      this.draw();
    }, { passive: false });
    c.addEventListener('pointerdown', (e) => {
      const p = this.toImage(e);
      if (!p) return;
      c.setPointerCapture(e.pointerId);
      const roiMode = this.tool === 'roi' && e.button === 0, distMode = this.tool === 'dist' && e.button === 0;
      drag = { x: e.clientX, y: e.clientY, ww: this.ww, wl: this.wl, roi: roiMode, dist: distMode, start: p };
      if (roiMode) { this.roi = { cx: p.x, cy: p.y, r: 1 }; this.draw(); }
      if (distMode) { this.line = { x0: p.x, y0: p.y, x1: p.x, y1: p.y }; this.draw(); }
    });
    c.addEventListener('pointermove', (e) => {
      const p = this.toImage(e);
      if (p && p.x >= 0 && p.y >= 0 && p.x < p.cur.w && p.y < p.cur.h) {
        this.hover = { hu: p.cur.img[Math.floor(p.y) * p.cur.w + Math.floor(p.x)] };
      } else this.hover = null;
      if (!drag) { this.onInfo(this.info()); return; }
      if (drag.roi) {
        this.roi.r = Math.max(1, Math.hypot(p.x - drag.start.x, (p.y - drag.start.y) * p.cur.aspect));
      } else if (drag.dist) {
        this.line.x1 = p.x; this.line.y1 = p.y;
      } else {
        this.ww = Math.max(1, drag.ww + (e.clientX - drag.x) * 4);
        this.wl = drag.wl - (e.clientY - drag.y) * 2;
        this.onWindowChange?.();
      }
      this.draw();
    });
    const end = () => { drag = null; };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
    c.addEventListener('dblclick', () => { this.zoom = 1; this.draw(); });
  }
}

// Dibuja un topograma (proyección) en un canvas con escala de grises y devuelve la transformación z ↔ píxel.
export function drawTopogram(canvas, topo, { lo = 0, hi = null } = {}) {
  if (hi == null) { hi = 0; for (const v of topo.img) if (v > hi) hi = v; hi = Math.max(1, hi * 0.95); }
  const off = document.createElement('canvas');
  off.width = topo.cols; off.height = topo.rows;
  const ctx = off.getContext('2d');
  const id = ctx.createImageData(topo.cols, topo.rows);
  for (let p = 0; p < topo.cols * topo.rows; p++) {
    const g = Math.max(0, Math.min(255, ((topo.img[p] - lo) / (hi - lo)) * 255));
    id.data[4 * p] = id.data[4 * p + 1] = id.data[4 * p + 2] = g; id.data[4 * p + 3] = 255;
  }
  ctx.putImageData(id, 0, 0);
  return off;
}
